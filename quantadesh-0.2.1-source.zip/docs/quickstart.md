# Quick Start

```python
import quantadesh as qa

# Black-Scholes
qa.bs_price(100, 100, 1, 0.05, 0.2, option_type="call")

# Monte Carlo (returns MCResult)
mc = qa.mc_price(100, 100, 1, 0.05, 0.2, paths=100_000, option_type="call", seed=42)
print(mc.price, mc.se, mc.ci95)

# Greeks
g = qa.bs_greeks(100, 100, 1, 0.05, 0.2, option_type="call")

# Full report
report = qa.analyze_option(S=100, K=100, T=1, r=0.05, sigma=0.2)
```
