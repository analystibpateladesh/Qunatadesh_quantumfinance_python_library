# quantadesh

A comprehensive, beginner-friendly quantitative finance toolkit by **Adesh Patel**.

See the [Quick Start](quickstart.md) and [API Reference](api/pricing.md).
