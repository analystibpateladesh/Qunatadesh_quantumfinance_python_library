# quantadesh — Examples Cookbook

Runnable scripts and CLI recipes that exercise every major area of the library.

## Setup

```bash
pip install quantadesh[plot]   # for charts
pip install quantadesh[market] # optional: yfinance market data
```

## Recipes

### 1. CLI — option pricing

```bash
quantadesh option --S 100 --K 100 --T 1 --r 0.05 --sigma 0.2 --type call
quantadesh option --config examples/configs/option.json --plot out/payoff.png
quantadesh option --config examples/configs/option.json --json
```

### 2. CLI — bond analytics

```bash
quantadesh bond --face 1000 --coupon 0.05 --ytm 0.04 --years 10
quantadesh bond --config examples/configs/bond.json --json
```

### 3. CLI — portfolio diagnostics from a CSV

```bash
quantadesh portfolio --csv examples/configs/portfolio_returns.csv --rf 0.02 \
                     --plot out/drawdown.png
```

### 4. CLI — efficient frontier

```bash
quantadesh frontier --config examples/configs/frontier.json --plot out/frontier.png
```

### 5. CLI — Monte Carlo paths plot

```bash
quantadesh mc-paths --S 100 --T 1 --r 0.05 --sigma 0.2 --paths 30 --plot out/paths.png
```

### 6. CLI — implied vol smile

```bash
quantadesh smile --config examples/configs/smile.json --plot out/smile.png
```

### 7. Python scripts

Each `scripts/*.py` is self-contained. Run with:

```bash
python examples/scripts/01_option_basics.py
python examples/scripts/02_exotics.py
python examples/scripts/03_fixed_income.py
python examples/scripts/04_portfolio.py
python examples/scripts/05_risk_garch.py
python examples/scripts/06_short_rate_models.py
python examples/scripts/07_full_dashboard.py
```

All scripts save plots to `examples/out/`.
