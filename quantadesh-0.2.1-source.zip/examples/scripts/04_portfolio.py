"""04 — Portfolio: efficient frontier + max Sharpe + plot."""
import os, numpy as np, quantadesh as qa
from quantadesh.plot import plot_efficient_frontier
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)

mu = np.array([0.09, 0.07, 0.03, 0.05])
cov = np.array([[0.040,0.018,0.001,0.005],
                [0.018,0.050,0.0015,0.006],
                [0.001,0.0015,0.005,0.0008],
                [0.005,0.006,0.0008,0.030]])
front = qa.efficient_frontier(mu, cov, n_points=60, rf=0.02,
                              assets=["US Eq","Intl Eq","Bonds","Gold"])
best = qa.max_sharpe(mu, cov, rf=0.02, assets=["US Eq","Intl Eq","Bonds","Gold"])
print("Max Sharpe portfolio:", best)
print("Weights:", dict(zip(best.assets, best.weights.round(4))))
plot_efficient_frontier(front, rf=0.02, save_path=os.path.join(out, "04_frontier.png"))
print(f"plot saved to {out}/04_frontier.png")
