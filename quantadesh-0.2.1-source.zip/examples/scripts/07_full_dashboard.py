"""07 — End-to-end: option report + MC paths + smile + frontier in one run."""
import os, numpy as np, quantadesh as qa
from quantadesh.plot import (plot_payoff, plot_mc_paths, plot_vol_smile,
                             plot_efficient_frontier)
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)

# Option
rep = qa.analyze_option(S=100,K=100,T=1,r=0.05,sigma=0.2,paths=20_000,seed=1)
print("BS:", rep["Black-Scholes"], "MC:", rep["Monte Carlo"])
plot_payoff(K=100, option_type="call", premium=rep["Black-Scholes"],
            save_path=os.path.join(out, "07_payoff.png"))
plot_mc_paths(100, 1, 0.05, 0.2, paths=40, steps=252, seed=1,
              save_path=os.path.join(out, "07_paths.png"))

# Smile (synthetic prices from sticky-strike vol)
S,T,r = 100,0.5,0.03
strikes = [80,90,95,100,105,110,120]
vols    = [0.32,0.27,0.245,0.22,0.215,0.225,0.26]
prices = {K: qa.bs_price(S,K,T,r,v,option_type="call") for K,v in zip(strikes,vols)}
plot_vol_smile(S,T,r,prices, save_path=os.path.join(out, "07_smile.png"))

# Frontier
mu = np.array([0.09,0.07,0.03,0.05])
cov = np.array([[0.04,0.018,0.001,0.005],[0.018,0.05,0.0015,0.006],
                [0.001,0.0015,0.005,0.0008],[0.005,0.006,0.0008,0.03]])
front = qa.efficient_frontier(mu, cov, n_points=50, rf=0.02)
plot_efficient_frontier(front, rf=0.02, save_path=os.path.join(out, "07_frontier.png"))
print(f"all plots saved to {out}/")
