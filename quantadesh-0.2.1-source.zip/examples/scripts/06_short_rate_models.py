"""06 — Short-rate models: simulate Vasicek & CIR; closed-form ZCB."""
import os, numpy as np, quantadesh as qa
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)

vp = qa.vasicek_simulate(0.03, 0.5, 0.04, 0.01, T=5, steps=252, paths=200, seed=0)
cp = qa.cir_simulate(0.03, 0.5, 0.04, 0.05, T=5, steps=252, paths=200, seed=0)
print(f"Vasicek mean(rT) = {vp[:,-1].mean():.4f}, target={0.04}")
print(f"CIR     mean(rT) = {cp[:,-1].mean():.4f}, target={0.04}")
print("Vasicek ZCB(5y):", qa.vasicek_zcb_price(0.03, 0.5, 0.04, 0.01, 5))
print("CIR     ZCB(5y):", qa.cir_zcb_price(0.03, 0.5, 0.04, 0.05, 5))

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    t = np.linspace(0, 5, vp.shape[1])
    for i in range(40): axes[0].plot(t, vp[i], lw=0.6, alpha=0.6)
    axes[0].set_title("Vasicek paths"); axes[0].grid(alpha=0.3)
    for i in range(40): axes[1].plot(t, cp[i], lw=0.6, alpha=0.6)
    axes[1].set_title("CIR paths"); axes[1].grid(alpha=0.3)
    fig.savefig(os.path.join(out, "06_short_rate.png"), dpi=130, bbox_inches="tight")
    print(f"plot saved to {out}/06_short_rate.png")
except ImportError:
    pass
