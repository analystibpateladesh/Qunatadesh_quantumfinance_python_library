"""05 — Risk: VaR/CVaR, drawdown plot, GARCH(1,1) MLE."""
import os, numpy as np, quantadesh as qa
from quantadesh.plot import plot_drawdown, plot_pnl_distribution
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(42)
r = rng.normal(0.0004, 0.012, 1500)

var = qa.historical_var(r, 0.95); cvar = qa.historical_cvar(r, 0.95)
print(var); print(cvar); print("MaxDD:", qa.max_drawdown(r))
print("GARCH:", qa.garch11_fit(r))

plot_drawdown(r, save_path=os.path.join(out, "05_drawdown.png"))
plot_pnl_distribution(r, var_value=var.value, cvar_value=cvar.value,
                      save_path=os.path.join(out, "05_pnl_dist.png"))
print(f"plots saved to {out}/")
