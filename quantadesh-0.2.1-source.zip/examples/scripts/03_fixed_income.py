"""03 — Fixed income: bond analytics + yield curve plot."""
import os, quantadesh as qa
from quantadesh.plot import plot_yield_curve
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)

print(qa.analyze_bond(face=1000, coupon=0.05, ytm=0.04, years=10))

curve = qa.YieldCurve([0.25, 1, 2, 5, 10, 30],
                      [0.045, 0.046, 0.047, 0.048, 0.049, 0.050])
print("DF(7y):", curve.discount_factor(7))
print("Fwd 5y -> 10y:", curve.forward_rate(5, 10))
plot_yield_curve(curve, t_max=30, save_path=os.path.join(out, "03_yield_curve.png"))
print(f"plot saved to {out}/03_yield_curve.png")
