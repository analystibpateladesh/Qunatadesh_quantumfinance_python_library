"""01 — Option basics: BS vs MC vs Binomial, full Greeks, payoff plot."""
import os, quantadesh as qa
from quantadesh.plot import plot_payoff, plot_greeks_surface
out = os.path.join(os.path.dirname(__file__), "..", "out"); os.makedirs(out, exist_ok=True)

S, K, T, r, sigma = 100, 100, 1.0, 0.05, 0.2
report = qa.analyze_option(S=S, K=K, T=T, r=r, sigma=sigma, paths=50_000, seed=42)
for k, v in report.items(): print(f"{k}: {v}")

plot_payoff(K=K, option_type="call", premium=report["Black-Scholes"],
            save_path=os.path.join(out, "01_payoff.png"))
plot_greeks_surface(K=K, T=T, r=r, sigma=sigma, greek="delta",
                    save_path=os.path.join(out, "01_delta_surface.png"))
print(f"\nplots saved to {out}/")
