"""02 — Exotics: Asian, Barrier, Lookback, Digital."""
import quantadesh as qa
S, K, T, r, sigma = 100, 100, 1, 0.05, 0.2
print("Asian (arith) call:", qa.asian_price(S,K,T,r,sigma, paths=30_000, steps=50, seed=1))
print("Up-and-out call (H=120):", qa.barrier_price(S,K,120,T,r,sigma,
        barrier_type="up-and-out", option_type="call", paths=30_000, seed=1))
print("Lookback call:", qa.lookback_price(S,T,r,sigma, paths=30_000, steps=100, seed=1))
print("Digital call (cash=1):", qa.digital_price(S,K,T,r,sigma, cash=1.0, option_type="call"))
