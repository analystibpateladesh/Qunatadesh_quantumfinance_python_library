# quantadesh

[![PyPI version](https://img.shields.io/badge/pypi-v0.2.0-blue)](#)
[![Python](https://img.shields.io/badge/python-3.9%2B-blue)](#)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](#)

**A comprehensive, beginner-friendly quantitative finance toolkit by Adesh Patel.**

`quantadesh` covers the majority of what a quant practitioner computes day-to-day —
options pricing, Greeks, exotics, fixed income, short-rate models, portfolio
optimization, risk measures, and time-series diagnostics — behind a clean,
**consistent API** designed so AI assistants (and humans) can write code against
it correctly the first time.

## Why quantadesh

- **Consistent signatures everywhere**: every pricer is `f(S, K, T, r, sigma, ..., option_type="call")` — `option_type` is always last.
- **Structured outputs**: Monte Carlo returns `MCResult(price, se, paths, ci95)`, Greeks return `GreeksResult(...)`, never bare tuples.
- **One-call analyzers**: `qa.analyze_option(...)` or `qa.analyze_bond(...)` give you everything in one go.
- **No surprise dependencies**: only `numpy`, `pandas`, `scipy`. `yfinance` is optional.
- **Deeply tested**: 30+ pytest cases covering parity, convergence, and edge cases.

## Installation

```bash
pip install quantadesh
# optional extras:
pip install quantadesh[market]   # adds yfinance market-data wrappers
pip install quantadesh[plot]     # adds matplotlib for examples
pip install quantadesh[dev]      # everything (tests, docs, market, plots)
```

## Quick start

```python
import quantadesh as qa

# 1) Plain Black-Scholes — returns a float
qa.bs_price(S=100, K=100, T=1, r=0.05, sigma=0.2, option_type="call")
# 10.4506

# 2) Monte Carlo — returns a structured MCResult, never a bare tuple
mc = qa.mc_price(S=100, K=100, T=1, r=0.05, sigma=0.2, paths=200_000, option_type="call", seed=42)
print(mc)
# MCResult(price=10.4485, se=0.034170, paths=200000, ci95=(10.3815, 10.5155))

# 3) Greeks — full bundle (incl. higher-order vanna/volga/charm)
g = qa.bs_greeks(100, 100, 1, 0.05, 0.2, option_type="call")
print(g.delta, g.gamma, g.vega, g.theta, g.rho)

# 4) One-call full analysis
report = qa.analyze_option(S=100, K=100, T=1, r=0.05, sigma=0.2)
print(report["Black-Scholes"], report["Binomial (American)"], report["Greeks"])
```

## What's inside

| Area | Functions |
|---|---|
| **European pricing** | `bs_price`, `bachelier_price`, `black76_price`, `binomial_price`, `mc_price`, `heston_price` |
| **American options** | `binomial_price(..., american=True)` |
| **Implied vol** | `bs_implied_vol` (Brent solver) |
| **Exotics** | `asian_price`, `barrier_price` (4 types), `lookback_price`, `digital_price` |
| **Greeks** | `bs_greeks` (Δ, Γ, Vega, Θ, ρ + vanna, volga, charm), `numerical_greeks` |
| **Fixed income** | `bond_price`, `ytm`, `duration`, `modified_duration`, `convexity`, `YieldCurve` |
| **Short-rate models** | `vasicek_simulate`/`vasicek_zcb_price`, `cir_simulate`/`cir_zcb_price`, `hull_white_simulate` |
| **Portfolio** | `efficient_frontier`, `min_variance`, `max_sharpe`, `capm_beta`, `black_litterman` |
| **Risk** | `historical_var`, `parametric_var`, `monte_carlo_var`, `historical_cvar`, `parametric_cvar`, `max_drawdown` |
| **Time series** | `simple_returns`, `log_returns`, `realized_vol`, `ewma_vol`, `garch11_fit`, `adf_test`, `hurst_exponent`, `ljung_box` |
| **Performance** | `sharpe_ratio`, `sortino_ratio`, `calmar_ratio`, `information_ratio`, `omega_ratio`, `treynor_ratio` |
| **Market data** | `qa.market.get_prices`, `qa.market.get_returns` (optional, requires `yfinance`) |
| **Result types** | `MCResult`, `GreeksResult`, `PricingResult`, `BondResult`, `PortfolioResult`, `RiskResult`, `FrontierResult` |
| **Analyzers** | `analyze_option`, `analyze_bond`, `analyze_portfolio` |

## API design rules (what makes this library AI-friendly)

1. **Same signature everywhere**: `f(S, K, T, r, sigma, ..., option_type="call")`.
2. **Structured returns**: every non-trivial function returns a dataclass with `__repr__`, `to_dict()`, and `float()` cast.
3. **Validation up front**: `option_type` is normalized; positives are checked; clear errors.
4. **No silent magic**: optional behaviour is opt-in via keyword (`return_result=True`, `american=True`, `antithetic=True`).

## License

MIT © Adesh Patel
