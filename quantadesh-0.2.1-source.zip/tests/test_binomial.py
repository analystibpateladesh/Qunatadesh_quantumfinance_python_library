import quantadesh as qa

def test_european_binomial_converges_to_bs():
    bs = qa.bs_price(100,100,1,0.05,0.2,option_type="call")
    bin_ = qa.binomial_price(100,100,1,0.05,0.2, steps=2000, option_type="call")
    assert abs(bs - bin_) < 0.02

def test_american_put_premium():
    eu = qa.binomial_price(100,100,1,0.05,0.2, steps=500, american=False, option_type="put")
    am = qa.binomial_price(100,100,1,0.05,0.2, steps=500, american=True, option_type="put")
    assert am >= eu - 1e-6
