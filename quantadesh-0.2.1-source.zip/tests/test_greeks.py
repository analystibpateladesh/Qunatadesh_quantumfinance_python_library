import quantadesh as qa

def test_call_delta_in_range():
    g = qa.bs_greeks(100,100,1,0.05,0.2, option_type="call")
    assert 0 < g.delta < 1
    assert g.gamma > 0
    assert g.vega > 0

def test_numerical_matches_analytical():
    a = qa.bs_greeks(100,100,1,0.05,0.2, option_type="call")
    n = qa.numerical_greeks(qa.bs_price, 100,100,1,0.05,0.2, option_type="call")
    assert abs(a.delta - n.delta) < 1e-3
    assert abs(a.vega - n.vega) < 1e-3
