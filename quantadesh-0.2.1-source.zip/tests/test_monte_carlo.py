import math, quantadesh as qa

def test_mc_close_to_bs():
    res = qa.mc_price(100,100,1,0.05,0.2, paths=200_000, option_type="call", seed=42)
    bs = qa.bs_price(100,100,1,0.05,0.2,option_type="call")
    assert isinstance(res, qa.MCResult)
    assert abs(res.price - bs) < 0.1
    assert res.ci95[0] < res.price < res.ci95[1]
    assert res.se > 0

def test_mc_repr():
    res = qa.mc_price(100,100,1,0.05,0.2, paths=10_000, option_type="put", seed=1)
    assert "MCResult" in repr(res)
