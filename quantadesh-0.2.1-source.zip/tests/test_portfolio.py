import numpy as np, quantadesh as qa

def test_min_variance_long_only():
    mu = [0.08, 0.12, 0.15]
    cov = np.array([[0.04,0.006,0.008],[0.006,0.09,0.012],[0.008,0.012,0.16]])
    p = qa.min_variance(mu, cov)
    assert abs(p.weights.sum() - 1) < 1e-6
    assert (p.weights >= -1e-9).all()

def test_max_sharpe():
    mu = [0.08, 0.12, 0.15]
    cov = np.diag([0.04,0.09,0.16])
    p = qa.max_sharpe(mu, cov, rf=0.02)
    assert p.sharpe > 0

def test_capm_beta():
    rng = np.random.default_rng(0)
    mkt = rng.normal(0.0005, 0.01, 1000)
    asset = 1.2 * mkt + rng.normal(0, 0.005, 1000)
    b = qa.capm_beta(asset, mkt)
    assert abs(b - 1.2) < 0.1
