import quantadesh as qa

def test_analyze_option_keys():
    out = qa.analyze_option(S=100,K=100,T=1,r=0.05,sigma=0.2, paths=10_000, steps=200, seed=1)
    assert "Black-Scholes" in out and "Monte Carlo" in out and "Greeks" in out
    assert isinstance(out["Monte Carlo"], qa.MCResult)
    assert "Put-Call Parity" in out

def test_analyze_bond_keys():
    out = qa.analyze_bond(face=1000, coupon=0.05, ytm=0.04, years=10)
    assert {"price","macaulay_duration","modified_duration","convexity"} <= out.keys()
