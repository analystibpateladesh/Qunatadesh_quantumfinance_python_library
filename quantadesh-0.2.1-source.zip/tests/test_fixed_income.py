import quantadesh as qa

def test_par_bond():
    p = qa.bond_price(1000, 0.05, 0.05, 10, freq=2)
    assert abs(p - 1000) < 1e-6

def test_ytm_roundtrip():
    p = qa.bond_price(1000, 0.06, 0.045, 7, freq=2)
    y = qa.ytm(p, 1000, 0.06, 7, freq=2)
    assert abs(y - 0.045) < 1e-8

def test_duration_positive():
    d = qa.duration(1000, 0.05, 0.05, 10, freq=2)
    assert 5 < d < 10

def test_yield_curve():
    c = qa.YieldCurve([0.5,1,2,5,10],[0.04,0.045,0.05,0.052,0.053])
    df = c.discount_factor(3)
    assert 0 < df < 1
    fwd = c.forward_rate(1, 2)
    assert 0.03 < fwd < 0.07
