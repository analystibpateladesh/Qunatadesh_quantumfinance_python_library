import numpy as np, quantadesh as qa

def test_sharpe_known():
    rng = np.random.default_rng(0)
    r = rng.normal(0.0008, 0.01, 2000)
    s = qa.sharpe_ratio(r, rf=0.0)
    assert s > 0

def test_garch_fits():
    rng = np.random.default_rng(0)
    r = rng.normal(0, 0.01, 1000)
    fit = qa.garch11_fit(r)
    assert fit["omega"] > 0
    assert 0 <= fit["alpha"] < 1
    assert 0 <= fit["beta"] < 1
    assert fit["persistence"] < 1

def test_hurst_random_walk():
    rng = np.random.default_rng(0)
    rw = np.cumsum(rng.standard_normal(2000))
    h = qa.hurst_exponent(rw)
    assert 0.3 < h < 0.7  # noisy but bounded
