import quantadesh as qa

def test_vasicek_paths_shape():
    paths = qa.vasicek_simulate(0.03, 0.5, 0.04, 0.01, 1.0, steps=252, paths=100, seed=0)
    assert paths.shape == (100, 253)

def test_vasicek_zcb_in_unit():
    p = qa.vasicek_zcb_price(0.03, 0.5, 0.04, 0.01, 5)
    assert 0 < p < 1

def test_cir_zcb():
    p = qa.cir_zcb_price(0.03, 0.5, 0.04, 0.05, 5)
    assert 0 < p < 1
