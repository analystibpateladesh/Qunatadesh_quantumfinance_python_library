import numpy as np, quantadesh as qa

def test_var_positive_for_loss_dist():
    rng = np.random.default_rng(0)
    r = rng.normal(0, 0.01, 5000)
    v = qa.historical_var(r, 0.95)
    assert v.value > 0
    assert isinstance(v, qa.RiskResult)

def test_cvar_ge_var():
    rng = np.random.default_rng(0)
    r = rng.normal(0, 0.01, 5000)
    v = qa.historical_var(r, 0.95).value
    c = qa.historical_cvar(r, 0.95).value
    assert c >= v - 1e-9

def test_max_drawdown_negative():
    rng = np.random.default_rng(1)
    r = rng.normal(0, 0.01, 1000)
    assert qa.max_drawdown(r) <= 0
