import math, pytest, quantadesh as qa

def test_call_put_parity():
    S,K,T,r,sigma = 100,100,1.0,0.05,0.2
    c = qa.bs_price(S,K,T,r,sigma,option_type="call")
    p = qa.bs_price(S,K,T,r,sigma,option_type="put")
    assert math.isclose(c - p, S - K*math.exp(-r*T), rel_tol=1e-10)

def test_known_value():
    # textbook: S=K=100,T=1,r=5%,sigma=20% -> call ~10.4506
    c = qa.bs_price(100,100,1,0.05,0.2,option_type="call")
    assert abs(c - 10.4506) < 1e-3

def test_implied_vol_roundtrip():
    sigma = 0.27
    price = qa.bs_price(110, 100, 0.5, 0.03, sigma, option_type="put")
    iv = qa.bs_implied_vol(price, 110, 100, 0.5, 0.03, option_type="put")
    assert abs(iv - sigma) < 1e-6

def test_returns_pricing_result():
    pr = qa.bs_price(100,100,1,0.05,0.2,option_type="call",return_result=True)
    assert pr.model == "Black-Scholes"
    assert float(pr) > 0
