import quantadesh as qa

def test_asian_cheaper_than_vanilla():
    asian = qa.asian_price(100,100,1,0.05,0.2, paths=20_000, steps=50, option_type="call", seed=1)
    bs = qa.bs_price(100,100,1,0.05,0.2,option_type="call")
    assert asian.price < bs   # arithmetic-average call typically cheaper

def test_barrier_kio_kio_parity():
    ki = qa.barrier_price(100,100,120,1,0.05,0.2,
        barrier_type="up-and-in", option_type="call", paths=20_000, seed=1)
    ko = qa.barrier_price(100,100,120,1,0.05,0.2,
        barrier_type="up-and-out", option_type="call", paths=20_000, seed=1)
    bs = qa.bs_price(100,100,1,0.05,0.2,option_type="call")
    assert abs((ki.price + ko.price) - bs) < 0.5  # MC noise

def test_digital_in_unit_interval():
    d = qa.digital_price(100,100,1,0.05,0.2, cash=1.0, option_type="call")
    assert 0 < d < 1
