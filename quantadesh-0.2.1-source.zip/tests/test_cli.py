import json, os, subprocess, sys, tempfile, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
EX   = ROOT / "examples" / "configs"

def run(*args):
    r = subprocess.run([sys.executable, "-m", "quantadesh.cli", *args],
                       capture_output=True, text=True, cwd=str(ROOT))
    assert r.returncode == 0, f"CLI failed: {r.stderr}\n{r.stdout}"
    return r.stdout, r.stderr

def test_cli_version():
    out, _ = run("version"); assert "0.2" in out

def test_cli_option_flags():
    out, _ = run("--json","option","--S","100","--K","100","--T","1","--r","0.05",
                 "--sigma","0.2","--type","call","--paths","5000","--seed","1")
    data = json.loads(out)
    assert "Black-Scholes" in data and "Monte Carlo" in data

def test_cli_option_config(tmp_path):
    out, _ = run("--json","option","--config",str(EX/"option.json"),"--paths","5000")
    data = json.loads(out)
    assert data["Black-Scholes"] > 0

def test_cli_bond_config():
    out, _ = run("--json","bond","--config",str(EX/"bond.json"))
    data = json.loads(out)
    assert "macaulay_duration" in data

def test_cli_portfolio_csv():
    out, _ = run("--json","portfolio","--csv",str(EX/"portfolio_returns.csv"),"--rf","0.02")
    data = json.loads(out); assert "sharpe" in data

def test_cli_frontier_plot(tmp_path):
    plot = tmp_path / "f.png"
    out, _ = run("--json","frontier","--config",str(EX/"frontier.json"),
                 "--plot",str(plot))
    assert plot.exists() and plot.stat().st_size > 1000

def test_cli_mc_paths_plot(tmp_path):
    plot = tmp_path / "p.png"
    run("mc-paths","--S","100","--T","1","--r","0.05","--sigma","0.2",
        "--paths","20","--seed","1","--plot",str(plot))
    assert plot.exists()

def test_cli_smile_plot(tmp_path):
    plot = tmp_path / "s.png"
    run("smile","--config",str(EX/"smile.json"),"--plot",str(plot))
    assert plot.exists()
