# Changelog

## v0.2.1 (2026-04-26)

### New
- **CLI** — `quantadesh` console command. Subcommands: `option`, `bond`, `portfolio`, `frontier`, `mc-paths`, `smile`, `version`, `list`. Supports JSON & YAML configs, `--json` output, `--plot PATH` for chart export.
- **Plotting module** (`quantadesh.plot`) — matplotlib helpers: `plot_payoff`, `plot_mc_paths`, `plot_vol_smile`, `plot_efficient_frontier`, `plot_drawdown`, `plot_yield_curve`, `plot_greeks_surface`, `plot_pnl_distribution`. Optional via `pip install quantadesh[plot]`.
- **Cookbook** — `examples/scripts/01..07_*.py` runnable end-to-end recipes covering options, exotics, fixed income, portfolios, risk/GARCH, short-rate models, and a full dashboard. Sample CLI configs in `examples/configs/`.

### Fixed
- Removed circular import in `quantadesh.utils`.

## v0.2.0 (2026-04-26)

Major expansion + API consistency overhaul.

### New
- **Models**: Bachelier, Black-76, Heston (semi-analytical), American binomial, GBM path simulator.
- **Exotics**: Asian (arithmetic/geometric), Barrier (4 KO/KI types), Lookback (floating strike), Digital.
- **Implied vol**: `bs_implied_vol` (Brent solver).
- **Greeks**: higher-order (vanna, volga, charm); generic `numerical_greeks` for any pricer.
- **Fixed income**: bond pricing, YTM, Macaulay/modified duration, convexity, full `YieldCurve` class with linear/log-DF interpolation and forward-rate computation.
- **Short-rate models**: Vasicek (sim + closed-form ZCB), CIR (sim + closed-form ZCB), Hull-White.
- **Portfolio**: `efficient_frontier`, `min_variance`, `max_sharpe`, CAPM beta, Black-Litterman posterior.
- **Risk**: parametric / historical / Monte Carlo VaR; parametric / historical CVaR; drawdown analytics.
- **Time series**: EWMA vol, GARCH(1,1) MLE, ADF test, Hurst exponent, Ljung-Box, ACF.
- **Performance**: Sharpe, Sortino, Calmar, Information, Omega, Treynor.
- **Result types**: `MCResult`, `GreeksResult`, `PricingResult`, `BondResult`, `PortfolioResult`, `RiskResult`, `FrontierResult` — all with `__repr__`, `to_dict()`, and `float()` casting where it makes sense.
- **Unified analyzers**: `analyze_option`, `analyze_bond`, `analyze_portfolio`.

### Changed
- **Standardized signatures**: every pricer is now `f(S, K, T, r, sigma, ..., option_type="call")`. `option_type` is the LAST positional argument, default `"call"`.
- **MC returns MCResult**: `mc_price` no longer returns a bare float — it returns `MCResult(price, se, paths, ci95)`.
- **Validation everywhere**: clear `ValueError`/`TypeError` for bad inputs.

### Tests
- 30+ pytest cases: put-call parity, BS-binomial-MC convergence, IV round-trip, KI+KO=vanilla parity, bond YTM round-trip, GARCH stability, etc.

## v0.1.0
- Initial release: Black-Scholes, basic Monte Carlo, basic Greeks.
