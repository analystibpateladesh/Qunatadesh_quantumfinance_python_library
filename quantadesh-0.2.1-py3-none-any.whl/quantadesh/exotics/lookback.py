"""Lookback options (floating strike) via Monte Carlo."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional
from ..utils.validation import validate_option_type
from ..utils.results import MCResult


def lookback_price(
    S, T, r, sigma, q=0.0,
    paths: int = 50_000, steps: int = 100,
    option_type: str = "call",
    *, seed: Optional[int] = None,
) -> MCResult:
    """Floating-strike lookback: call pays S_T - min(S_t), put pays max(S_t) - S_T."""
    ot = validate_option_type(option_type)
    rng = np.random.default_rng(seed)
    dt = T / steps
    drift = (r - q - 0.5 * sigma ** 2) * dt
    Z = rng.standard_normal(size=(paths, steps))
    log_S = np.log(S) + np.cumsum(drift + sigma * math.sqrt(dt) * Z, axis=1)
    S_paths = np.exp(log_S)
    ST = S_paths[:, -1]
    if ot == "call":
        payoff = ST - S_paths.min(axis=1)
    else:
        payoff = S_paths.max(axis=1) - ST
    disc = math.exp(-r * T) * payoff
    price = float(disc.mean()); se = float(disc.std(ddof=1) / math.sqrt(paths))
    return MCResult(price=price, se=se, paths=paths,
                    ci95=(price - 1.96 * se, price + 1.96 * se),
                    model="Lookback-floating", option_type=ot,
                    inputs=dict(S=S, T=T, r=r, sigma=sigma))
