"""Digital (cash-or-nothing) European options — closed form under BS."""
from __future__ import annotations
import math
from scipy.stats import norm
from ..utils.validation import validate_option_type
from ..utils.results import PricingResult


def digital_price(S, K, T, r, sigma, q=0.0, cash: float = 1.0,
                  option_type: str = "call", *, return_result: bool = False):
    """Cash-or-nothing digital: pays `cash` if ITM at expiry, else 0."""
    ot = validate_option_type(option_type)
    if T <= 0 or sigma <= 0:
        itm = (S > K) if ot == "call" else (S < K)
        price = cash * float(itm) * math.exp(-r * T)
    else:
        d2 = (math.log(S / K) + (r - q - 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
        price = cash * math.exp(-r * T) * (norm.cdf(d2) if ot == "call" else norm.cdf(-d2))
    if return_result:
        return PricingResult(price=price, model="Digital-cash-or-nothing", option_type=ot,
                             inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma, q=q, cash=cash))
    return price
