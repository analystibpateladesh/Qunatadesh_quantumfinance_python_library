"""Asian (arithmetic-average) options via Monte Carlo."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional
from ..utils.validation import validate_option_type
from ..utils.results import MCResult


def asian_price(
    S, K, T, r, sigma, q=0.0,
    paths: int = 50_000, steps: int = 50,
    average_type: str = "arithmetic",   # 'arithmetic' or 'geometric'
    option_type: str = "call",
    *, seed: Optional[int] = None, antithetic: bool = True,
) -> MCResult:
    """Asian average-price option (fixed strike) via MC."""
    ot = validate_option_type(option_type)
    rng = np.random.default_rng(seed)
    n_half = paths // 2 if antithetic else paths
    Z = rng.standard_normal(size=(n_half, steps))
    if antithetic:
        Z = np.vstack([Z, -Z])
    n = Z.shape[0]
    dt = T / steps
    drift = (r - q - 0.5 * sigma ** 2) * dt
    diff = sigma * math.sqrt(dt) * Z
    log_S = np.log(S) + np.cumsum(drift + diff, axis=1)
    S_paths = np.exp(log_S)
    if average_type == "arithmetic":
        avg = S_paths.mean(axis=1)
    elif average_type == "geometric":
        avg = np.exp(np.log(S_paths).mean(axis=1))
    else:
        raise ValueError("average_type must be 'arithmetic' or 'geometric'")
    payoff = np.maximum(avg - K, 0.0) if ot == "call" else np.maximum(K - avg, 0.0)
    disc = math.exp(-r * T) * payoff
    price = float(disc.mean()); se = float(disc.std(ddof=1) / math.sqrt(n))
    return MCResult(price=price, se=se, paths=n, ci95=(price - 1.96 * se, price + 1.96 * se),
                    model=f"Asian-{average_type}", option_type=ot,
                    inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma, steps=steps))
