"""Knock-in / knock-out barrier options via Monte Carlo."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional
from ..utils.validation import validate_option_type
from ..utils.results import MCResult


def barrier_price(
    S, K, H, T, r, sigma, q=0.0,
    barrier_type: str = "up-and-out",  # up-and-out, up-and-in, down-and-out, down-and-in
    option_type: str = "call",
    paths: int = 50_000, steps: int = 100,
    rebate: float = 0.0,
    *, seed: Optional[int] = None,
) -> MCResult:
    ot = validate_option_type(option_type)
    bt = barrier_type.lower()
    if bt not in {"up-and-out", "up-and-in", "down-and-out", "down-and-in"}:
        raise ValueError("Invalid barrier_type")
    rng = np.random.default_rng(seed)
    dt = T / steps
    drift = (r - q - 0.5 * sigma ** 2) * dt
    Z = rng.standard_normal(size=(paths, steps))
    log_S = np.log(S) + np.cumsum(drift + sigma * math.sqrt(dt) * Z, axis=1)
    S_paths = np.exp(log_S)
    max_S = S_paths.max(axis=1); min_S = S_paths.min(axis=1)
    if "up" in bt:
        hit = max_S >= H
    else:
        hit = min_S <= H
    ST = S_paths[:, -1]
    intrinsic = np.maximum(ST - K, 0.0) if ot == "call" else np.maximum(K - ST, 0.0)
    if "out" in bt:
        payoff = np.where(hit, rebate, intrinsic)
    else:  # knock-in
        payoff = np.where(hit, intrinsic, rebate)
    disc = math.exp(-r * T) * payoff
    price = float(disc.mean()); se = float(disc.std(ddof=1) / math.sqrt(paths))
    return MCResult(price=price, se=se, paths=paths,
                    ci95=(price - 1.96 * se, price + 1.96 * se),
                    model=f"Barrier-{bt}", option_type=ot,
                    inputs=dict(S=S, K=K, H=H, T=T, r=r, sigma=sigma, rebate=rebate))
