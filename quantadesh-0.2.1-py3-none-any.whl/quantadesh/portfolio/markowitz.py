"""
Markowitz mean-variance optimization (long-only, fully-invested).
Uses scipy.optimize.minimize (SLSQP) — works without cvxpy.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from typing import Optional, Sequence
from ..utils.results import PortfolioResult, FrontierResult


def portfolio_stats(weights: np.ndarray, mu: np.ndarray, cov: np.ndarray, rf: float = 0.0):
    w = np.asarray(weights, dtype=float)
    ret = float(w @ mu)
    vol = float(np.sqrt(w @ cov @ w))
    sharpe = (ret - rf) / vol if vol > 0 else 0.0
    return ret, vol, sharpe


def _bounds_constraints(n: int, allow_short: bool):
    cons = ({"type": "eq", "fun": lambda w: np.sum(w) - 1.0},)
    bounds = [(-1.0, 1.0)] * n if allow_short else [(0.0, 1.0)] * n
    return bounds, cons


def min_variance(mu: Sequence[float], cov: np.ndarray, *, allow_short: bool = False,
                 assets: Optional[list] = None, rf: float = 0.0) -> PortfolioResult:
    mu = np.asarray(mu, dtype=float); cov = np.asarray(cov, dtype=float)
    n = len(mu)
    bounds, cons = _bounds_constraints(n, allow_short)
    w0 = np.full(n, 1 / n)
    res = minimize(lambda w: w @ cov @ w, w0, method="SLSQP", bounds=bounds, constraints=cons)
    if not res.success:
        raise RuntimeError(f"min_variance failed: {res.message}")
    w = res.x
    ret, vol, sh = portfolio_stats(w, mu, cov, rf)
    return PortfolioResult(weights=w, expected_return=ret, volatility=vol, sharpe=sh, assets=assets)


def max_sharpe(mu: Sequence[float], cov: np.ndarray, rf: float = 0.0,
               *, allow_short: bool = False, assets: Optional[list] = None) -> PortfolioResult:
    mu = np.asarray(mu, dtype=float); cov = np.asarray(cov, dtype=float)
    n = len(mu)
    bounds, cons = _bounds_constraints(n, allow_short)
    w0 = np.full(n, 1 / n)
    def neg_sharpe(w):
        ret = w @ mu; vol = np.sqrt(w @ cov @ w)
        return -(ret - rf) / vol if vol > 0 else 1e6
    res = minimize(neg_sharpe, w0, method="SLSQP", bounds=bounds, constraints=cons)
    if not res.success:
        raise RuntimeError(f"max_sharpe failed: {res.message}")
    w = res.x
    ret, vol, sh = portfolio_stats(w, mu, cov, rf)
    return PortfolioResult(weights=w, expected_return=ret, volatility=vol, sharpe=sh, assets=assets)


def efficient_frontier(mu, cov, n_points: int = 50, rf: float = 0.0,
                       *, allow_short: bool = False, assets=None) -> FrontierResult:
    mu = np.asarray(mu, dtype=float); cov = np.asarray(cov, dtype=float)
    n = len(mu)
    target_returns = np.linspace(mu.min(), mu.max(), n_points)
    bounds = [(-1.0, 1.0)] * n if allow_short else [(0.0, 1.0)] * n
    weights, vols, sharpes = [], [], []
    for tr in target_returns:
        cons = (
            {"type": "eq", "fun": lambda w: np.sum(w) - 1.0},
            {"type": "eq", "fun": lambda w, tr=tr: w @ mu - tr},
        )
        w0 = np.full(n, 1 / n)
        res = minimize(lambda w: w @ cov @ w, w0, method="SLSQP", bounds=bounds, constraints=cons)
        if res.success:
            w = res.x; vol = float(np.sqrt(w @ cov @ w))
            weights.append(w); vols.append(vol)
            sharpes.append((tr - rf) / vol if vol > 0 else 0.0)
        else:
            weights.append(np.full(n, np.nan)); vols.append(np.nan); sharpes.append(np.nan)
    return FrontierResult(returns=np.asarray(target_returns), volatilities=np.asarray(vols),
                          weights=np.asarray(weights), sharpes=np.asarray(sharpes), assets=assets)
