"""Black-Litterman posterior expected returns."""
from __future__ import annotations
import numpy as np
from typing import Optional


def black_litterman(
    cov: np.ndarray, market_weights: np.ndarray, P: np.ndarray, Q: np.ndarray,
    tau: float = 0.05, risk_aversion: float = 2.5,
    omega: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Returns posterior expected returns given views.

    cov            : (n,n) covariance of asset returns
    market_weights : (n,) market-cap weights
    P              : (k,n) view selection matrix
    Q              : (k,) view returns
    tau            : scalar — uncertainty in prior
    risk_aversion  : delta in pi = delta * cov @ w_mkt
    omega          : (k,k) view uncertainty; default = diag(P (tau*cov) P^T)
    """
    cov = np.asarray(cov, dtype=float)
    w = np.asarray(market_weights, dtype=float)
    P = np.asarray(P, dtype=float); Q = np.asarray(Q, dtype=float)
    pi = risk_aversion * cov @ w
    tau_cov = tau * cov
    if omega is None:
        omega = np.diag(np.diag(P @ tau_cov @ P.T))
    M_inv = np.linalg.inv(np.linalg.inv(tau_cov) + P.T @ np.linalg.inv(omega) @ P)
    mu_bl = M_inv @ (np.linalg.inv(tau_cov) @ pi + P.T @ np.linalg.inv(omega) @ Q)
    return mu_bl
