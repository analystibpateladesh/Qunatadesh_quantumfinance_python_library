"""CAPM utilities."""
from __future__ import annotations
import numpy as np


def capm_beta(asset_returns, market_returns) -> float:
    a = np.asarray(asset_returns, dtype=float); m = np.asarray(market_returns, dtype=float)
    cov = np.cov(a, m, ddof=1)[0, 1]
    var_m = np.var(m, ddof=1)
    return float(cov / var_m)


def capm_expected_return(beta: float, rf: float, market_return: float) -> float:
    return float(rf + beta * (market_return - rf))
