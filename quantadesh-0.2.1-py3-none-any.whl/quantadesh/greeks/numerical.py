"""Finite-difference Greeks — works with ANY pricer callable."""
from __future__ import annotations
from typing import Callable
from ..utils.results import GreeksResult


def numerical_greeks(
    pricer: Callable, S, K, T, r, sigma, q=0.0,
    option_type: str = "call",
    *, h_S: float = 0.01, h_sigma: float = 1e-4, h_T: float = 1e-4, h_r: float = 1e-4,
) -> GreeksResult:
    """
    Central-difference Greeks. `pricer` must accept (S, K, T, r, sigma, q, option_type)
    and return a float (or anything castable to float).
    """
    def f(S_, K_, T_, r_, sigma_):
        return float(pricer(S_, K_, T_, r_, sigma_, q, option_type))

    base = f(S, K, T, r, sigma)
    p_up = f(S * (1 + h_S), K, T, r, sigma); p_dn = f(S * (1 - h_S), K, T, r, sigma)
    delta = (p_up - p_dn) / (2 * S * h_S)
    gamma = (p_up - 2 * base + p_dn) / ((S * h_S) ** 2)
    vega = (f(S, K, T, r, sigma + h_sigma) - f(S, K, T, r, sigma - h_sigma)) / (2 * h_sigma) * 0.01
    theta = -(f(S, K, T + h_T, r, sigma) - f(S, K, T - h_T, r, sigma)) / (2 * h_T) / 365.0
    rho = (f(S, K, T, r + h_r, sigma) - f(S, K, T, r - h_r, sigma)) / (2 * h_r) * 0.01
    return GreeksResult(delta=delta, gamma=gamma, vega=vega, theta=theta, rho=rho, method="finite-difference")
