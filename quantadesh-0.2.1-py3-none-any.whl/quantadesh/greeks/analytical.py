"""Closed-form Black-Scholes Greeks (incl. higher-order: vanna, volga, charm)."""
from __future__ import annotations
import math
from scipy.stats import norm
from ..utils.validation import validate_option_type
from ..utils.results import GreeksResult


def bs_greeks(S, K, T, r, sigma, q=0.0, option_type="call", *, higher_order: bool = True) -> GreeksResult:
    ot = validate_option_type(option_type)
    if T <= 0 or sigma <= 0:
        return GreeksResult(0, 0, 0, 0, 0, method="analytical")
    sqT = math.sqrt(T)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * sqT)
    d2 = d1 - sigma * sqT
    pdf = norm.pdf(d1)
    df_q = math.exp(-q * T); df_r = math.exp(-r * T)

    if ot == "call":
        delta = df_q * norm.cdf(d1)
        theta = (-S * pdf * sigma * df_q / (2 * sqT)
                 - r * K * df_r * norm.cdf(d2) + q * S * df_q * norm.cdf(d1))
        rho = K * T * df_r * norm.cdf(d2)
    else:
        delta = -df_q * norm.cdf(-d1)
        theta = (-S * pdf * sigma * df_q / (2 * sqT)
                 + r * K * df_r * norm.cdf(-d2) - q * S * df_q * norm.cdf(-d1))
        rho = -K * T * df_r * norm.cdf(-d2)

    gamma = df_q * pdf / (S * sigma * sqT)
    vega = S * df_q * pdf * sqT * 0.01   # per 1% vol change
    theta = theta / 365.0                  # per day
    rho = rho * 0.01                       # per 1% rate change

    vanna = volga = charm = None
    if higher_order:
        vanna = -df_q * pdf * d2 / sigma * 0.01
        volga = vega * d1 * d2 / sigma
        charm_ann = (q * df_q * (norm.cdf(d1) if ot == "call" else -norm.cdf(-d1))
                     - df_q * pdf * (2 * (r - q) * T - d2 * sigma * sqT) / (2 * T * sigma * sqT))
        charm = charm_ann / 365.0

    return GreeksResult(delta=delta, gamma=gamma, vega=vega, theta=theta, rho=rho,
                        vanna=vanna, volga=volga, charm=charm, method="analytical")
