"""Fixed-coupon bond analytics: price, YTM, duration, convexity."""
from __future__ import annotations
import numpy as np
from scipy.optimize import brentq
from ..utils.results import BondResult


def _cashflows(face: float, coupon_rate: float, n_periods: int, freq: int):
    c = face * coupon_rate / freq
    cfs = np.full(n_periods, c)
    cfs[-1] += face
    times = np.arange(1, n_periods + 1) / freq
    return cfs, times


def bond_price(face: float, coupon_rate: float, ytm_rate: float,
               years: float, freq: int = 2, *, return_result: bool = False):
    """Clean price of a fixed-coupon bond, given a yield-to-maturity."""
    n = int(round(years * freq))
    cfs, t = _cashflows(face, coupon_rate, n, freq)
    pv = float(np.sum(cfs / (1 + ytm_rate / freq) ** (t * freq)))
    if return_result:
        return BondResult(price=pv, ytm=ytm_rate,
                          inputs=dict(face=face, coupon=coupon_rate, years=years, freq=freq))
    return pv


def ytm(price: float, face: float, coupon_rate: float, years: float, freq: int = 2) -> float:
    """Yield-to-maturity solver via Brent."""
    def obj(y): return bond_price(face, coupon_rate, y, years, freq) - price
    return brentq(obj, -0.5, 5.0, xtol=1e-10)


def duration(face: float, coupon_rate: float, ytm_rate: float, years: float, freq: int = 2) -> float:
    """Macaulay duration."""
    n = int(round(years * freq))
    cfs, t = _cashflows(face, coupon_rate, n, freq)
    pv = cfs / (1 + ytm_rate / freq) ** (t * freq)
    return float(np.sum(t * pv) / np.sum(pv))


def modified_duration(face, coupon_rate, ytm_rate, years, freq=2) -> float:
    return duration(face, coupon_rate, ytm_rate, years, freq) / (1 + ytm_rate / freq)


def convexity(face: float, coupon_rate: float, ytm_rate: float, years: float, freq: int = 2) -> float:
    n = int(round(years * freq))
    cfs, t = _cashflows(face, coupon_rate, n, freq)
    y = ytm_rate / freq
    pv = cfs / (1 + y) ** (t * freq)
    conv = np.sum(t * (t + 1 / freq) * pv) / ((1 + y) ** 2)
    return float(conv / np.sum(pv))
