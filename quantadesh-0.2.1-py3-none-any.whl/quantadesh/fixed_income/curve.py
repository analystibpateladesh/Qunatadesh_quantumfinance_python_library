"""Yield curve with linear & log-DF interpolation. Bootstrap-friendly."""
from __future__ import annotations
import numpy as np
from typing import Sequence


class YieldCurve:
    """
    Build a zero-coupon yield curve from (tenor, zero_rate) pairs.
    Supports discount-factor lookups and forward-rate computation.

    Example:
        c = YieldCurve([0.25, 1, 2, 5, 10], [0.045, 0.046, 0.047, 0.048, 0.049])
        c.discount_factor(3.5)
        c.forward_rate(1, 2)   # 1y forward starting in 1y
    """
    def __init__(self, tenors: Sequence[float], zero_rates: Sequence[float],
                 method: str = "linear_zero"):
        self.tenors = np.asarray(tenors, dtype=float)
        self.rates = np.asarray(zero_rates, dtype=float)
        if len(self.tenors) != len(self.rates):
            raise ValueError("tenors and rates must have the same length")
        order = np.argsort(self.tenors)
        self.tenors = self.tenors[order]; self.rates = self.rates[order]
        if method not in {"linear_zero", "log_df"}:
            raise ValueError("method must be 'linear_zero' or 'log_df'")
        self.method = method

    def zero_rate(self, t: float) -> float:
        if t <= 0:
            return float(self.rates[0])
        if self.method == "linear_zero":
            return float(np.interp(t, self.tenors, self.rates))
        # log_df interpolation
        log_dfs = -self.rates * self.tenors
        log_df = float(np.interp(t, self.tenors, log_dfs))
        return -log_df / t

    def discount_factor(self, t: float) -> float:
        return float(np.exp(-self.zero_rate(t) * t))

    def forward_rate(self, t1: float, t2: float) -> float:
        """Continuously-compounded forward rate from t1 to t2."""
        if t2 <= t1:
            raise ValueError("t2 must be > t1")
        df1 = self.discount_factor(t1); df2 = self.discount_factor(t2)
        return float(np.log(df1 / df2) / (t2 - t1))

    def __repr__(self):
        return f"YieldCurve(n={len(self.tenors)}, method={self.method!r})"
