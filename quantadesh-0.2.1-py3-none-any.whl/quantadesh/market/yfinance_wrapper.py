"""
Optional yfinance wrapper. Install with:  pip install quantadesh[market]
"""
from __future__ import annotations
import pandas as pd


def _require_yf():
    try:
        import yfinance as yf  # type: ignore
        return yf
    except ImportError as e:
        raise ImportError("yfinance not installed. Run: pip install quantadesh[market]") from e


def get_prices(tickers, start=None, end=None, interval: str = "1d", auto_adjust: bool = True) -> pd.DataFrame:
    yf = _require_yf()
    if isinstance(tickers, str):
        tickers = [tickers]
    df = yf.download(tickers, start=start, end=end, interval=interval,
                     auto_adjust=auto_adjust, progress=False, group_by="ticker")
    # Normalize: return adjusted Close as DataFrame with one column per ticker
    if len(tickers) == 1:
        col = "Close" if "Close" in df.columns else df.columns[0]
        return df[[col]].rename(columns={col: tickers[0]})
    return pd.DataFrame({t: df[t]["Close"] for t in tickers if t in df.columns.get_level_values(0)})


def get_returns(tickers, start=None, end=None, interval: str = "1d",
                method: str = "log") -> pd.DataFrame:
    import numpy as np
    px = get_prices(tickers, start=start, end=end, interval=interval)
    return (np.log(px / px.shift(1)) if method == "log" else px.pct_change()).dropna()
