"""Input validation helpers — used everywhere for clean error messages."""
from typing import Any

VALID_OPTION_TYPES = {"call", "put", "c", "p"}

def validate_option_type(option_type: str) -> str:
    """Normalize and validate option_type. Returns 'call' or 'put'."""
    if not isinstance(option_type, str):
        raise TypeError(f"option_type must be str, got {type(option_type).__name__}")
    ot = option_type.lower().strip()
    if ot not in VALID_OPTION_TYPES:
        raise ValueError(f"option_type must be one of {VALID_OPTION_TYPES}, got '{option_type}'")
    return "call" if ot in {"call", "c"} else "put"

def validate_positive(name: str, value: Any) -> float:
    """Ensure a numeric input is strictly positive."""
    v = float(value)
    if v <= 0:
        raise ValueError(f"{name} must be > 0, got {v}")
    return v

def validate_nonneg(name: str, value: Any) -> float:
    v = float(value)
    if v < 0:
        raise ValueError(f"{name} must be >= 0, got {v}")
    return v
