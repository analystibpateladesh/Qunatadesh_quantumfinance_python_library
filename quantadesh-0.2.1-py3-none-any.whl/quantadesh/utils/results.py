"""
Structured result types — every quantadesh function returns a clean,
self-describing object instead of bare floats or tuples.

Why this matters: AI assistants and humans both write fewer bugs when the
output of a pricing call has named fields and a useful __repr__.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List, Tuple
import numpy as np


@dataclass
class PricingResult:
    """Standard output of any pricing function."""
    price: float
    model: str = ""
    option_type: Optional[str] = None
    inputs: Dict[str, Any] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        ot = f", option_type={self.option_type!r}" if self.option_type else ""
        return f"PricingResult(price={self.price:.6f}, model={self.model!r}{ot})"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def __float__(self) -> float:
        return float(self.price)


@dataclass
class MCResult:
    """Monte Carlo pricing result with full diagnostics."""
    price: float
    se: float                  # standard error of the price estimate
    paths: int
    ci95: Tuple[float, float]  # 95% confidence interval
    model: str = "MonteCarlo"
    option_type: Optional[str] = None
    payoff_samples: Optional[np.ndarray] = field(default=None, repr=False)
    inputs: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"MCResult(price={self.price:.4f}, se={self.se:.6f}, "
            f"paths={self.paths}, ci95=({self.ci95[0]:.4f}, {self.ci95[1]:.4f}))"
        )

    def __float__(self) -> float:
        return float(self.price)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("payoff_samples", None)
        return d


@dataclass
class GreeksResult:
    """Option Greeks bundle (analytical or numerical)."""
    delta: float
    gamma: float
    vega: float
    theta: float
    rho: float
    # higher-order (optional)
    vanna: Optional[float] = None
    volga: Optional[float] = None
    charm: Optional[float] = None
    method: str = "analytical"

    def __repr__(self) -> str:
        return (
            f"GreeksResult(delta={self.delta:.4f}, gamma={self.gamma:.4f}, "
            f"vega={self.vega:.4f}, theta={self.theta:.4f}, rho={self.rho:.4f})"
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BondResult:
    price: float
    ytm: Optional[float] = None
    macaulay_duration: Optional[float] = None
    modified_duration: Optional[float] = None
    convexity: Optional[float] = None
    accrued: float = 0.0
    inputs: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"BondResult(price={self.price:.4f}, ytm={self.ytm}, "
            f"mod_dur={self.modified_duration}, convexity={self.convexity})"
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PortfolioResult:
    weights: np.ndarray
    expected_return: float
    volatility: float
    sharpe: float
    assets: Optional[List[str]] = None

    def __repr__(self) -> str:
        return (
            f"PortfolioResult(ret={self.expected_return:.4f}, "
            f"vol={self.volatility:.4f}, sharpe={self.sharpe:.4f})"
        )

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "weights": list(map(float, self.weights)),
            "expected_return": self.expected_return,
            "volatility": self.volatility,
            "sharpe": self.sharpe,
            "assets": self.assets,
        }
        return d


@dataclass
class FrontierResult:
    returns: np.ndarray
    volatilities: np.ndarray
    weights: np.ndarray  # shape (n_points, n_assets)
    sharpes: np.ndarray
    assets: Optional[List[str]] = None

    def __repr__(self) -> str:
        return f"FrontierResult(points={len(self.returns)}, max_sharpe={self.sharpes.max():.4f})"


@dataclass
class RiskResult:
    metric: str            # 'VaR', 'CVaR', etc.
    value: float
    confidence: float
    method: str            # 'historical', 'parametric', 'monte_carlo'
    horizon: int = 1
    extra: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"RiskResult({self.metric}={self.value:.6f}, "
            f"conf={self.confidence:.2%}, method={self.method!r}, h={self.horizon})"
        )

    def __float__(self) -> float:
        return float(self.value)
