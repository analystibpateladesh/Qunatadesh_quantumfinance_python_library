"""
One-call unified analyzers — what users *actually* want to write:

    >>> qa.analyze_option(S=100, K=100, T=1, r=0.05, sigma=0.2)
    >>> qa.analyze_bond(face=1000, coupon=0.05, ytm=0.04, years=10)
    >>> qa.analyze_portfolio(returns_df)
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Optional, Dict, Any

from ..models.black_scholes import bs_price
from ..models.binomial import binomial_price
from ..models.monte_carlo import mc_price
from ..greeks.analytical import bs_greeks
from ..fixed_income.bond import bond_price, duration, modified_duration, convexity
from ..stats.performance import sharpe_ratio, sortino_ratio, calmar_ratio, annualized_return, annualized_vol
from ..risk.var import historical_var
from ..risk.cvar import historical_cvar
from ..risk.drawdown import max_drawdown


def analyze_option(S, K, T, r, sigma, q: float = 0.0,
                   option_type: str = "call",
                   *, paths: int = 50_000, steps: int = 500,
                   seed: Optional[int] = None) -> Dict[str, Any]:
    """
    One-call full option analysis: BS price, MC price (with CI), binomial European
    & American, all Greeks, and put-call parity check.
    """
    bs = bs_price(S, K, T, r, sigma, q, option_type)
    mc = mc_price(S, K, T, r, sigma, q, paths=paths, option_type=option_type, seed=seed)
    bin_eu = binomial_price(S, K, T, r, sigma, q, steps=steps, american=False, option_type=option_type)
    bin_am = binomial_price(S, K, T, r, sigma, q, steps=steps, american=True, option_type=option_type)
    greeks = bs_greeks(S, K, T, r, sigma, q, option_type)
    # parity diagnostic: C - P = S*e^-qT - K*e^-rT
    other = "put" if option_type.lower().startswith("c") else "call"
    other_bs = bs_price(S, K, T, r, sigma, q, other)
    parity_lhs = (bs - other_bs) if option_type.lower().startswith("c") else (other_bs - bs)
    parity_rhs = S * np.exp(-q * T) - K * np.exp(-r * T)
    return {
        "inputs": dict(S=S, K=K, T=T, r=r, sigma=sigma, q=q, option_type=option_type),
        "Black-Scholes": bs,
        "Monte Carlo": mc,
        "Binomial (European)": bin_eu,
        "Binomial (American)": bin_am,
        "Greeks": greeks,
        "Put-Call Parity": dict(lhs=float(parity_lhs), rhs=float(parity_rhs),
                                diff=float(parity_lhs - parity_rhs)),
    }


def analyze_bond(face: float, coupon: float, ytm: float, years: float,
                 freq: int = 2) -> Dict[str, Any]:
    """One-call bond analytics: price, durations, convexity."""
    return {
        "price": bond_price(face, coupon, ytm, years, freq),
        "macaulay_duration": duration(face, coupon, ytm, years, freq),
        "modified_duration": modified_duration(face, coupon, ytm, years, freq),
        "convexity": convexity(face, coupon, ytm, years, freq),
        "inputs": dict(face=face, coupon=coupon, ytm=ytm, years=years, freq=freq),
    }


def analyze_portfolio(returns, rf: float = 0.0,
                      benchmark=None, periods_per_year: int = 252) -> Dict[str, Any]:
    """
    One-call portfolio diagnostics from a return series (or DataFrame of returns).
    """
    r = pd.DataFrame(returns) if not isinstance(returns, pd.DataFrame) else returns
    if r.shape[1] > 1:
        # equal-weight if multiple columns
        port = r.mean(axis=1)
    else:
        port = r.iloc[:, 0]
    out = {
        "annualized_return": annualized_return(port, periods_per_year),
        "annualized_vol": annualized_vol(port, periods_per_year),
        "sharpe": sharpe_ratio(port, rf, periods_per_year),
        "sortino": sortino_ratio(port, rf, periods_per_year),
        "calmar": calmar_ratio(port, periods_per_year),
        "max_drawdown": max_drawdown(port),
        "VaR_95": historical_var(port, 0.95),
        "CVaR_95": historical_cvar(port, 0.95),
    }
    return out
