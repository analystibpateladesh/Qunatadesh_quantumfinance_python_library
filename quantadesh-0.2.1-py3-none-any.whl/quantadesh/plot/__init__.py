"""
Optional plotting helpers. Requires matplotlib:
    pip install quantadesh[plot]

Every function returns the matplotlib Figure so callers can save / display / tweak.
All functions accept `save_path=None` (display) or a path (save PNG/PDF).
"""
from .charts import (
    plot_payoff,
    plot_mc_paths,
    plot_vol_smile,
    plot_efficient_frontier,
    plot_drawdown,
    plot_yield_curve,
    plot_greeks_surface,
    plot_pnl_distribution,
)
__all__ = [
    "plot_payoff", "plot_mc_paths", "plot_vol_smile",
    "plot_efficient_frontier", "plot_drawdown", "plot_yield_curve",
    "plot_greeks_surface", "plot_pnl_distribution",
]
