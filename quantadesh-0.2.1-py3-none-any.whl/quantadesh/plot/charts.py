"""Matplotlib-based chart helpers for quantadesh outputs."""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Optional, Iterable

def _require_mpl():
    try:
        import matplotlib
        import matplotlib.pyplot as plt
        return matplotlib, plt
    except ImportError as e:
        raise ImportError("matplotlib not installed. Run: pip install quantadesh[plot]") from e

def _save_or_show(fig, save_path: Optional[str]):
    if save_path:
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def plot_payoff(K: float, option_type: str = "call",
                S_range: Optional[Iterable[float]] = None,
                premium: float = 0.0, *, save_path: Optional[str] = None):
    """Hockey-stick payoff at expiry, plus premium-shifted P&L."""
    _, plt = _require_mpl()
    if S_range is None:
        S_range = np.linspace(0.5 * K, 1.5 * K, 200)
    S = np.asarray(list(S_range), dtype=float)
    intrinsic = np.maximum(S - K, 0) if option_type.lower().startswith("c") else np.maximum(K - S, 0)
    pnl = intrinsic - premium
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(S, intrinsic, label=f"{option_type.title()} payoff at expiry", linewidth=2)
    ax.plot(S, pnl, label=f"P&L (premium={premium:g})", linestyle="--", linewidth=2)
    ax.axhline(0, color="black", linewidth=0.6)
    ax.axvline(K, color="grey", linestyle=":", label=f"Strike K={K:g}")
    ax.set_xlabel("Underlying price S"); ax.set_ylabel("Value")
    ax.set_title(f"{option_type.title()} option payoff (K={K:g})")
    ax.legend(); ax.grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_mc_paths(S: float, T: float, r: float, sigma: float, q: float = 0.0,
                  paths: int = 30, steps: int = 252, *,
                  seed: Optional[int] = None, save_path: Optional[str] = None):
    """Plot a sample of GBM Monte Carlo paths."""
    from ..models.monte_carlo import mc_paths as _paths
    _, plt = _require_mpl()
    P = _paths(S, T, r, sigma, q, paths=paths, steps=steps, seed=seed, antithetic=False)
    t = np.linspace(0, T, steps + 1)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for i in range(min(paths, P.shape[0])):
        ax.plot(t, P[i], linewidth=0.8, alpha=0.7)
    ax.axhline(S, color="black", linestyle=":", linewidth=0.7, label=f"S0={S:g}")
    ax.set_xlabel("Time (years)"); ax.set_ylabel("Price")
    ax.set_title(f"GBM Monte Carlo paths (n={paths}, σ={sigma:g})")
    ax.legend(); ax.grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_vol_smile(S: float, T: float, r: float, prices: dict,
                   *, q: float = 0.0, option_type: str = "call",
                   save_path: Optional[str] = None):
    """
    Plot implied-vol smile from a {strike: market_price} dict.
    """
    from ..models.black_scholes import bs_implied_vol
    _, plt = _require_mpl()
    Ks = sorted(prices.keys()); ivs = []
    for K in Ks:
        try:
            ivs.append(bs_implied_vol(prices[K], S, K, T, r, q, option_type))
        except Exception:
            ivs.append(np.nan)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(Ks, ivs, marker="o", linewidth=1.5)
    ax.set_xlabel("Strike K"); ax.set_ylabel("Implied volatility")
    ax.set_title(f"Implied vol smile (S={S:g}, T={T:g}y)")
    ax.grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_efficient_frontier(frontier, *, rf: float = 0.0,
                            save_path: Optional[str] = None):
    """Plot a FrontierResult; highlights max-Sharpe point."""
    _, plt = _require_mpl()
    fig, ax = plt.subplots(figsize=(8, 5))
    valid = ~np.isnan(frontier.volatilities)
    sc = ax.scatter(frontier.volatilities[valid], frontier.returns[valid],
                    c=frontier.sharpes[valid], cmap="viridis", s=18)
    plt.colorbar(sc, ax=ax, label="Sharpe ratio")
    if valid.any():
        idx = np.nanargmax(frontier.sharpes)
        ax.scatter([frontier.volatilities[idx]], [frontier.returns[idx]],
                   marker="*", color="red", s=220, label=f"Max Sharpe={frontier.sharpes[idx]:.3f}")
    ax.set_xlabel("Volatility (σ)"); ax.set_ylabel("Expected return")
    ax.set_title("Efficient frontier"); ax.legend(); ax.grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_drawdown(returns, *, save_path: Optional[str] = None):
    """Plot cumulative wealth and underwater drawdown chart."""
    from ..risk.drawdown import drawdown_series
    _, plt = _require_mpl()
    r = pd.Series(returns).fillna(0.0).reset_index(drop=True)
    wealth = (1 + r).cumprod()
    dd = drawdown_series(r).reset_index(drop=True)
    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    axes[0].plot(wealth.index, wealth.values, linewidth=1.4)
    axes[0].set_ylabel("Cumulative wealth"); axes[0].grid(alpha=0.3)
    axes[0].set_title("Wealth curve & drawdowns")
    axes[1].fill_between(dd.index, dd.values, 0, color="crimson", alpha=0.4)
    axes[1].set_ylabel("Drawdown"); axes[1].set_xlabel("Period"); axes[1].grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_yield_curve(curve, t_max: float = 30.0, n: int = 200,
                     *, save_path: Optional[str] = None):
    """Plot zero & instantaneous-forward curves from a YieldCurve object."""
    _, plt = _require_mpl()
    ts = np.linspace(0.05, t_max, n)
    zeros = [curve.zero_rate(t) for t in ts]
    fwds = [curve.forward_rate(t, t + 0.25) for t in ts[:-1]]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(ts, zeros, label="Zero rate", linewidth=2)
    ax.plot(ts[:-1], fwds, label="3M forward rate", linestyle="--")
    ax.scatter(curve.tenors, curve.rates, color="red", zorder=5, label="Knot points")
    ax.set_xlabel("Tenor (years)"); ax.set_ylabel("Rate")
    ax.set_title("Yield curve"); ax.legend(); ax.grid(alpha=0.3)
    return _save_or_show(fig, save_path)


def plot_greeks_surface(K: float, T: float, r: float, sigma: float, q: float = 0.0,
                        option_type: str = "call",
                        S_range: Optional[Iterable[float]] = None,
                        T_range: Optional[Iterable[float]] = None,
                        greek: str = "delta",
                        *, save_path: Optional[str] = None):
    """Heatmap of a single Greek across (S, T) grid."""
    from ..greeks.analytical import bs_greeks
    _, plt = _require_mpl()
    if S_range is None: S_range = np.linspace(0.6 * K, 1.4 * K, 40)
    if T_range is None: T_range = np.linspace(0.05, max(T, 1.0), 40)
    S_arr = np.asarray(list(S_range)); T_arr = np.asarray(list(T_range))
    Z = np.empty((len(T_arr), len(S_arr)))
    for i, t in enumerate(T_arr):
        for j, s in enumerate(S_arr):
            g = bs_greeks(s, K, t, r, sigma, q, option_type)
            Z[i, j] = getattr(g, greek)
    fig, ax = plt.subplots(figsize=(8, 5))
    im = ax.imshow(Z, origin="lower", aspect="auto", cmap="RdBu_r",
                   extent=[S_arr.min(), S_arr.max(), T_arr.min(), T_arr.max()])
    plt.colorbar(im, ax=ax, label=greek.title())
    ax.set_xlabel("Spot S"); ax.set_ylabel("Time to maturity T")
    ax.set_title(f"{greek.title()} surface ({option_type}, K={K:g})")
    return _save_or_show(fig, save_path)


def plot_pnl_distribution(samples, var_value: Optional[float] = None,
                          cvar_value: Optional[float] = None,
                          *, bins: int = 60, save_path: Optional[str] = None):
    """Histogram of P&L / returns with optional VaR / CVaR overlays."""
    _, plt = _require_mpl()
    x = np.asarray(samples, dtype=float)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.hist(x, bins=bins, alpha=0.75, edgecolor="white")
    if var_value is not None:
        ax.axvline(-var_value, color="orange", linestyle="--", linewidth=2, label=f"VaR={var_value:.4f}")
    if cvar_value is not None:
        ax.axvline(-cvar_value, color="red", linestyle="--", linewidth=2, label=f"CVaR={cvar_value:.4f}")
    ax.set_xlabel("Return / P&L"); ax.set_ylabel("Frequency")
    ax.set_title("Return distribution"); ax.grid(alpha=0.3)
    if var_value is not None or cvar_value is not None:
        ax.legend()
    return _save_or_show(fig, save_path)
