"""
quantadesh CLI

Examples
--------
quantadesh option --S 100 --K 100 --T 1 --r 0.05 --sigma 0.2 --type call
quantadesh option --config examples/configs/option.json --plot out.png
quantadesh bond --face 1000 --coupon 0.05 --ytm 0.04 --years 10
quantadesh portfolio --csv returns.csv --rf 0.02 --plot dd.png
quantadesh frontier --config examples/configs/frontier.json --plot ef.png
quantadesh mc-paths --S 100 --T 1 --r 0.05 --sigma 0.2 --paths 30 --plot paths.png
quantadesh smile --config examples/configs/smile.json --plot smile.png
"""
from __future__ import annotations
import argparse
import json
import os
import sys
from typing import Any, Dict
import numpy as np
import pandas as pd

import quantadesh as qa
from quantadesh.utils.analyze import analyze_option, analyze_bond, analyze_portfolio


# ---------- helpers ----------

def _load_config(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    with open(path) as f:
        text = f.read()
    if path.lower().endswith((".yml", ".yaml")):
        try:
            import yaml
            return yaml.safe_load(text)
        except ImportError:
            print("YAML config requires `pip install pyyaml`. Use JSON instead.", file=sys.stderr)
            sys.exit(2)
    return json.loads(text)


def _merge(cli_args: argparse.Namespace, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """CLI flags override config-file values when explicitly set (not None)."""
    merged = dict(cfg)
    for k, v in vars(cli_args).items():
        if v is not None and k not in {"config", "plot", "json", "func"}:
            merged[k] = v
    return merged


def _to_jsonable(obj: Any) -> Any:
    """Recursively convert numpy/pandas/dataclass results to JSON-friendly forms."""
    if hasattr(obj, "to_dict"):
        return _to_jsonable(obj.to_dict())
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(x) for x in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)): return int(obj)
    if isinstance(obj, (np.floating,)): return float(obj)
    if isinstance(obj, pd.Series): return obj.to_list()
    return obj


def _emit(result: Any, json_mode: bool):
    if json_mode:
        print(json.dumps(_to_jsonable(result), indent=2, default=str))
    else:
        if isinstance(result, dict):
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print(result)


# ---------- subcommand handlers ----------

def cmd_option(args: argparse.Namespace) -> None:
    cfg = _load_config(args.config) if args.config else {}
    p = _merge(args, cfg)
    required = ["S", "K", "T", "r", "sigma"]
    missing = [k for k in required if k not in p]
    if missing:
        print(f"Missing required option params: {missing}", file=sys.stderr); sys.exit(2)

    report = analyze_option(
        S=float(p["S"]), K=float(p["K"]), T=float(p["T"]),
        r=float(p["r"]), sigma=float(p["sigma"]), q=float(p.get("q", 0.0)),
        option_type=str(p.get("type", p.get("option_type", "call"))),
        paths=int(p.get("paths", 50_000)),
        steps=int(p.get("steps", 500)),
        seed=p.get("seed"),
    )
    _emit(report, args.json)

    if args.plot:
        from quantadesh.plot import plot_payoff
        plot_payoff(K=float(p["K"]),
                    option_type=str(p.get("type", "call")),
                    premium=float(report["Black-Scholes"]),
                    save_path=args.plot)
        print(f"[plot] saved -> {args.plot}", file=sys.stderr)


def cmd_bond(args: argparse.Namespace) -> None:
    cfg = _load_config(args.config) if args.config else {}
    p = _merge(args, cfg)
    required = ["face", "coupon", "ytm", "years"]
    missing = [k for k in required if k not in p]
    if missing:
        print(f"Missing required bond params: {missing}", file=sys.stderr); sys.exit(2)
    out = analyze_bond(face=float(p["face"]), coupon=float(p["coupon"]),
                       ytm=float(p["ytm"]), years=float(p["years"]),
                       freq=int(p.get("freq", 2)))
    _emit(out, args.json)


def _load_returns(args, cfg) -> pd.DataFrame:
    csv = args.csv or cfg.get("csv")
    returns = cfg.get("returns")
    if csv:
        df = pd.read_csv(csv)
        # drop a date-like first column if present
        if df.columns[0].lower() in {"date", "time", "timestamp"}:
            df = df.iloc[:, 1:]
        return df
    if returns is not None:
        arr = np.asarray(returns, dtype=float)
        if arr.ndim == 1: arr = arr.reshape(-1, 1)
        return pd.DataFrame(arr)
    print("portfolio: provide --csv or 'returns' in config", file=sys.stderr); sys.exit(2)


def cmd_portfolio(args: argparse.Namespace) -> None:
    cfg = _load_config(args.config) if args.config else {}
    df = _load_returns(args, cfg)
    out = analyze_portfolio(df, rf=float(args.rf if args.rf is not None else cfg.get("rf", 0.0)),
                            periods_per_year=int(cfg.get("periods_per_year", 252)))
    _emit(out, args.json)
    if args.plot:
        from quantadesh.plot import plot_drawdown
        port = df.mean(axis=1) if df.shape[1] > 1 else df.iloc[:, 0]
        plot_drawdown(port, save_path=args.plot)
        print(f"[plot] saved -> {args.plot}", file=sys.stderr)


def cmd_frontier(args: argparse.Namespace) -> None:
    cfg = _load_config(args.config) if args.config else {}
    if "mu" not in cfg or "cov" not in cfg:
        print("frontier requires a config with 'mu' and 'cov'", file=sys.stderr); sys.exit(2)
    mu = np.asarray(cfg["mu"], dtype=float); cov = np.asarray(cfg["cov"], dtype=float)
    rf = float(args.rf if args.rf is not None else cfg.get("rf", 0.0))
    n_points = int(cfg.get("n_points", 50))
    allow_short = bool(cfg.get("allow_short", False))
    front = qa.efficient_frontier(mu, cov, n_points=n_points, rf=rf,
                                  allow_short=allow_short, assets=cfg.get("assets"))
    best = qa.max_sharpe(mu, cov, rf=rf, allow_short=allow_short, assets=cfg.get("assets"))
    _emit({"max_sharpe": best, "frontier_points": n_points,
           "max_sharpe_value": float(np.nanmax(front.sharpes))}, args.json)
    if args.plot:
        from quantadesh.plot import plot_efficient_frontier
        plot_efficient_frontier(front, rf=rf, save_path=args.plot)
        print(f"[plot] saved -> {args.plot}", file=sys.stderr)


def cmd_mc_paths(args: argparse.Namespace) -> None:
    if args.plot is None:
        print("mc-paths is plot-only; pass --plot <file.png>", file=sys.stderr); sys.exit(2)
    from quantadesh.plot import plot_mc_paths
    plot_mc_paths(S=args.S, T=args.T, r=args.r, sigma=args.sigma, q=args.q or 0.0,
                  paths=args.paths, steps=args.steps, seed=args.seed, save_path=args.plot)
    print(f"[plot] saved -> {args.plot}", file=sys.stderr)


def cmd_smile(args: argparse.Namespace) -> None:
    cfg = _load_config(args.config) if args.config else {}
    required = ["S", "T", "r", "prices"]
    missing = [k for k in required if k not in cfg]
    if missing:
        print(f"smile requires {required} in config", file=sys.stderr); sys.exit(2)
    if args.plot is None:
        print("smile is plot-only; pass --plot <file.png>", file=sys.stderr); sys.exit(2)
    from quantadesh.plot import plot_vol_smile
    prices = {float(k): float(v) for k, v in cfg["prices"].items()}
    plot_vol_smile(S=float(cfg["S"]), T=float(cfg["T"]), r=float(cfg["r"]), prices=prices,
                   q=float(cfg.get("q", 0.0)),
                   option_type=str(cfg.get("type", "call")), save_path=args.plot)
    print(f"[plot] saved -> {args.plot}", file=sys.stderr)


def cmd_version(args): print(qa.__version__)
def cmd_list(args):
    print("quantadesh public API:")
    for name in qa.__all__: print(f"  - {name}")


# ---------- parser ----------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="quantadesh",
        description="quantadesh CLI — quant finance from your terminal.",
    )
    p.add_argument("--json", action="store_true", help="JSON-formatted output")
    sub = p.add_subparsers(dest="command", required=True)

    # option
    sp = sub.add_parser("option", help="Full option analysis (BS, MC, binomial, Greeks)")
    sp.add_argument("--config")
    sp.add_argument("--S", type=float); sp.add_argument("--K", type=float)
    sp.add_argument("--T", type=float); sp.add_argument("--r", type=float)
    sp.add_argument("--sigma", type=float); sp.add_argument("--q", type=float)
    sp.add_argument("--type", choices=["call", "put"])
    sp.add_argument("--paths", type=int); sp.add_argument("--steps", type=int)
    sp.add_argument("--seed", type=int)
    sp.add_argument("--plot", help="Save payoff diagram to PATH")
    sp.set_defaults(func=cmd_option)

    # bond
    sp = sub.add_parser("bond", help="Bond price, duration, convexity")
    sp.add_argument("--config")
    sp.add_argument("--face", type=float); sp.add_argument("--coupon", type=float)
    sp.add_argument("--ytm", type=float); sp.add_argument("--years", type=float)
    sp.add_argument("--freq", type=int)
    sp.set_defaults(func=cmd_bond)

    # portfolio
    sp = sub.add_parser("portfolio", help="Portfolio diagnostics from a returns CSV/config")
    sp.add_argument("--config"); sp.add_argument("--csv")
    sp.add_argument("--rf", type=float)
    sp.add_argument("--plot", help="Save wealth & drawdown chart to PATH")
    sp.set_defaults(func=cmd_portfolio)

    # frontier
    sp = sub.add_parser("frontier", help="Efficient frontier from mu/cov in config")
    sp.add_argument("--config", required=True)
    sp.add_argument("--rf", type=float)
    sp.add_argument("--plot")
    sp.set_defaults(func=cmd_frontier)

    # mc-paths
    sp = sub.add_parser("mc-paths", help="Plot Monte Carlo GBM paths")
    sp.add_argument("--S", type=float, required=True); sp.add_argument("--T", type=float, required=True)
    sp.add_argument("--r", type=float, required=True); sp.add_argument("--sigma", type=float, required=True)
    sp.add_argument("--q", type=float, default=0.0)
    sp.add_argument("--paths", type=int, default=30); sp.add_argument("--steps", type=int, default=252)
    sp.add_argument("--seed", type=int)
    sp.add_argument("--plot", required=True)
    sp.set_defaults(func=cmd_mc_paths)

    # smile
    sp = sub.add_parser("smile", help="Plot implied-vol smile from market prices")
    sp.add_argument("--config", required=True)
    sp.add_argument("--plot", required=True)
    sp.set_defaults(func=cmd_smile)

    sub.add_parser("version", help="Print version").set_defaults(func=cmd_version)
    sub.add_parser("list", help="List public API symbols").set_defaults(func=cmd_list)
    return p


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
