"""
quantadesh — A comprehensive quantitative finance toolkit.

Author: Adesh Patel
Version: 0.2.0

Quick start:
    >>> import quantadesh as qa
    >>> qa.bs_price(S=100, K=100, T=1, r=0.05, sigma=0.2, option_type="call")
    >>> qa.analyze_option(S=100, K=100, T=1, r=0.05, sigma=0.2)

Sub-packages:
    models        — Black-Scholes, Bachelier, Black-76, Binomial, Monte Carlo, Heston
    exotics       — Asian, Barrier, Lookback, Digital, Chooser
    greeks        — Analytical & finite-difference Greeks (incl. higher-order)
    fixed_income  — Bonds, YTM, duration, convexity, yield curves
    rates         — Vasicek, CIR, Hull-White short-rate models
    portfolio     — Markowitz, Black-Litterman, CAPM, Fama-French
    risk          — VaR, CVaR/ES, drawdowns, stress tests
    timeseries    — Returns, GARCH, EWMA, ADF, cointegration, Hurst
    stats         — Performance metrics (Sharpe, Sortino, Calmar, Information ratio)
    market        — yfinance wrappers (optional)
    utils         — Result types & helpers
"""
__version__ = "0.2.1"
__author__ = "Adesh Patel"

# Top-level convenience exports — clean, consistent, "import qa, just works"
from .models.black_scholes import bs_price, bs_implied_vol
from .models.bachelier import bachelier_price
from .models.black76 import black76_price
from .models.binomial import binomial_price
from .models.monte_carlo import mc_price, mc_paths
from .models.heston import heston_price
from .exotics.asian import asian_price
from .exotics.barrier import barrier_price
from .exotics.lookback import lookback_price
from .exotics.digital import digital_price
from .greeks.analytical import bs_greeks
from .greeks.numerical import numerical_greeks
from .fixed_income.bond import bond_price, ytm, duration, convexity, modified_duration
from .fixed_income.curve import YieldCurve
from .rates.vasicek import vasicek_simulate, vasicek_zcb_price
from .rates.cir import cir_simulate, cir_zcb_price
from .rates.hull_white import hull_white_simulate
from .portfolio.markowitz import efficient_frontier, min_variance, max_sharpe
from .portfolio.capm import capm_beta, capm_expected_return
from .portfolio.black_litterman import black_litterman
from .risk.var import historical_var, parametric_var, monte_carlo_var
from .risk.cvar import historical_cvar, parametric_cvar
from .risk.drawdown import max_drawdown, drawdown_series
from .timeseries.returns import simple_returns, log_returns, cumulative_returns
from .timeseries.volatility import realized_vol, ewma_vol, garch11_fit
from .timeseries.tests import adf_test, hurst_exponent, ljung_box
from .stats.performance import sharpe_ratio, sortino_ratio, calmar_ratio, information_ratio, omega_ratio, treynor_ratio
from .utils.results import (
    MCResult, GreeksResult, PricingResult, BondResult,
    PortfolioResult, RiskResult, FrontierResult,
)
from .utils.analyze import analyze_option, analyze_portfolio, analyze_bond

__all__ = [
    # version
    "__version__", "__author__",
    # pricing
    "bs_price", "bs_implied_vol", "bachelier_price", "black76_price",
    "binomial_price", "mc_price", "mc_paths", "heston_price",
    # exotics
    "asian_price", "barrier_price", "lookback_price", "digital_price",
    # greeks
    "bs_greeks", "numerical_greeks",
    # fixed income
    "bond_price", "ytm", "duration", "modified_duration", "convexity", "YieldCurve",
    # rates
    "vasicek_simulate", "vasicek_zcb_price", "cir_simulate", "cir_zcb_price", "hull_white_simulate",
    # portfolio
    "efficient_frontier", "min_variance", "max_sharpe",
    "capm_beta", "capm_expected_return", "black_litterman",
    # risk
    "historical_var", "parametric_var", "monte_carlo_var",
    "historical_cvar", "parametric_cvar",
    "max_drawdown", "drawdown_series",
    # timeseries
    "simple_returns", "log_returns", "cumulative_returns",
    "realized_vol", "ewma_vol", "garch11_fit",
    "adf_test", "hurst_exponent", "ljung_box",
    # stats
    "sharpe_ratio", "sortino_ratio", "calmar_ratio",
    "information_ratio", "omega_ratio", "treynor_ratio",
    # results
    "MCResult", "GreeksResult", "PricingResult", "BondResult",
    "PortfolioResult", "RiskResult", "FrontierResult",
    # analyzers
    "analyze_option", "analyze_portfolio", "analyze_bond",
]
