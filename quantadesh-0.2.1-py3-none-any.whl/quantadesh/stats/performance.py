"""Performance ratios — clean, vectorized, well-defined edge cases."""
from __future__ import annotations
import numpy as np
from ..risk.drawdown import max_drawdown


def annualized_return(returns, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    return float(np.mean(r) * periods_per_year)


def annualized_vol(returns, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    return float(np.std(r, ddof=1) * np.sqrt(periods_per_year))


def sharpe_ratio(returns, rf: float = 0.0, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    excess = r - rf / periods_per_year
    sd = excess.std(ddof=1)
    if sd == 0: return 0.0
    return float(excess.mean() / sd * np.sqrt(periods_per_year))


def sortino_ratio(returns, rf: float = 0.0, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    excess = r - rf / periods_per_year
    downside = excess[excess < 0]
    dd = np.sqrt(np.mean(downside ** 2)) if len(downside) else 0.0
    if dd == 0: return 0.0
    return float(excess.mean() / dd * np.sqrt(periods_per_year))


def calmar_ratio(returns, periods_per_year: int = 252) -> float:
    mdd = abs(max_drawdown(returns))
    if mdd == 0: return 0.0
    return float(annualized_return(returns, periods_per_year) / mdd)


def information_ratio(returns, benchmark, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float); b = np.asarray(benchmark, dtype=float)
    diff = r - b
    sd = diff.std(ddof=1)
    if sd == 0: return 0.0
    return float(diff.mean() / sd * np.sqrt(periods_per_year))


def omega_ratio(returns, threshold: float = 0.0) -> float:
    r = np.asarray(returns, dtype=float) - threshold
    gains = r[r > 0].sum(); losses = -r[r < 0].sum()
    if losses == 0: return float("inf")
    return float(gains / losses)


def treynor_ratio(returns, beta: float, rf: float = 0.0, periods_per_year: int = 252) -> float:
    if beta == 0: return 0.0
    return float((annualized_return(returns, periods_per_year) - rf) / beta)
