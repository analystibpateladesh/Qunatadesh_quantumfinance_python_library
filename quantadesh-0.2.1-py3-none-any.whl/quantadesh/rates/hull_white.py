"""Hull-White (extended Vasicek) one-factor model with constant params."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional, Callable


def hull_white_simulate(r0: float, a: float, sigma: float,
                        theta: Callable[[float], float] | float,
                        T: float, steps: int = 252, paths: int = 1000,
                        *, seed: Optional[int] = None) -> np.ndarray:
    """
    dr = (theta(t) - a*r) dt + sigma dW

    `theta` may be a callable theta(t) or a constant float.
    """
    rng = np.random.default_rng(seed)
    dt = T / steps
    r = np.full((paths, steps + 1), r0, dtype=float)
    sqdt = math.sqrt(dt)
    th = theta if callable(theta) else (lambda t, v=theta: v)
    for k in range(1, steps + 1):
        t = k * dt
        Z = rng.standard_normal(paths)
        r[:, k] = r[:, k - 1] + (th(t) - a * r[:, k - 1]) * dt + sigma * sqdt * Z
    return r
