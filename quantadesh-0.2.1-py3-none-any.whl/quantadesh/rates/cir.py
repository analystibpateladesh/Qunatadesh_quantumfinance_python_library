"""Cox-Ingersoll-Ross short-rate model: dr = a(b-r)dt + sigma sqrt(r) dW."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional


def cir_simulate(r0: float, a: float, b: float, sigma: float,
                 T: float, steps: int = 252, paths: int = 1000,
                 *, seed: Optional[int] = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    dt = T / steps
    r = np.full((paths, steps + 1), r0, dtype=float)
    sqdt = math.sqrt(dt)
    for t in range(1, steps + 1):
        Z = rng.standard_normal(paths)
        prev = np.maximum(r[:, t - 1], 0.0)
        r[:, t] = prev + a * (b - prev) * dt + sigma * np.sqrt(prev) * sqdt * Z
        r[:, t] = np.maximum(r[:, t], 0.0)
    return r


def cir_zcb_price(r0: float, a: float, b: float, sigma: float, T: float) -> float:
    """Closed-form CIR zero-coupon bond price P(0,T)."""
    h = math.sqrt(a * a + 2 * sigma * sigma)
    denom = 2 * h + (a + h) * (math.exp(h * T) - 1)
    A = (2 * h * math.exp((a + h) * T / 2) / denom) ** (2 * a * b / sigma ** 2)
    B = 2 * (math.exp(h * T) - 1) / denom
    return float(A * math.exp(-B * r0))
