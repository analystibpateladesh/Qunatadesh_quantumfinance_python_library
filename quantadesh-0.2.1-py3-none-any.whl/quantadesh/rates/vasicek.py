"""Vasicek short-rate model: dr = a(b - r)dt + sigma dW."""
from __future__ import annotations
import math
import numpy as np
from typing import Optional


def vasicek_simulate(r0: float, a: float, b: float, sigma: float,
                     T: float, steps: int = 252, paths: int = 1000,
                     *, seed: Optional[int] = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    dt = T / steps
    r = np.full((paths, steps + 1), r0, dtype=float)
    sqdt = math.sqrt(dt)
    for t in range(1, steps + 1):
        Z = rng.standard_normal(paths)
        r[:, t] = r[:, t - 1] + a * (b - r[:, t - 1]) * dt + sigma * sqdt * Z
    return r


def vasicek_zcb_price(r0: float, a: float, b: float, sigma: float, T: float) -> float:
    """Closed-form Vasicek zero-coupon bond price P(0,T)."""
    if a == 0:
        B = T
    else:
        B = (1 - math.exp(-a * T)) / a
    A = math.exp((b - sigma ** 2 / (2 * a ** 2)) * (B - T) - (sigma ** 2 / (4 * a)) * B ** 2)
    return float(A * math.exp(-B * r0))
