"""Volatility estimators: realized, EWMA, GARCH(1,1) MLE."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import minimize


def realized_vol(returns, periods_per_year: int = 252) -> float:
    r = np.asarray(returns, dtype=float)
    return float(r.std(ddof=1) * np.sqrt(periods_per_year))


def ewma_vol(returns, lam: float = 0.94, periods_per_year: int = 252) -> pd.Series:
    """RiskMetrics-style EWMA volatility series."""
    r = pd.Series(returns).astype(float).fillna(0.0)
    var = pd.Series(index=r.index, dtype=float)
    var.iloc[0] = r.var(ddof=1)
    for i in range(1, len(r)):
        var.iloc[i] = lam * var.iloc[i - 1] + (1 - lam) * r.iloc[i - 1] ** 2
    return np.sqrt(var * periods_per_year)


def garch11_fit(returns, *, periods_per_year: int = 252) -> dict:
    """
    Maximum-likelihood GARCH(1,1): sigma2_t = omega + alpha * eps^2 + beta * sigma2_{t-1}.
    Returns dict with omega, alpha, beta, persistence, unconditional vol, log-likelihood.
    """
    r = np.asarray(returns, dtype=float)
    r = r[~np.isnan(r)]
    n = len(r)

    def neg_ll(params):
        omega, alpha, beta = params
        if omega <= 0 or alpha < 0 or beta < 0 or alpha + beta >= 0.999:
            return 1e10
        sigma2 = np.empty(n)
        sigma2[0] = r.var(ddof=1)
        for t in range(1, n):
            sigma2[t] = omega + alpha * r[t - 1] ** 2 + beta * sigma2[t - 1]
        ll = -0.5 * np.sum(np.log(2 * np.pi) + np.log(sigma2) + r ** 2 / sigma2)
        return -ll

    x0 = [r.var() * 0.05, 0.05, 0.9]
    res = minimize(neg_ll, x0, method="Nelder-Mead", options={"xatol": 1e-8, "fatol": 1e-8, "maxiter": 5000})
    omega, alpha, beta = res.x
    persistence = alpha + beta
    uncond = float(np.sqrt(omega / max(1 - persistence, 1e-12)) * np.sqrt(periods_per_year))
    return dict(omega=float(omega), alpha=float(alpha), beta=float(beta),
                persistence=float(persistence), unconditional_vol=uncond,
                loglik=float(-res.fun), success=bool(res.success))
