"""Return calculations."""
from __future__ import annotations
import numpy as np
import pandas as pd


def simple_returns(prices) -> pd.Series:
    p = pd.Series(prices); return p.pct_change().dropna()


def log_returns(prices) -> pd.Series:
    p = pd.Series(prices); return np.log(p / p.shift(1)).dropna()


def cumulative_returns(returns) -> pd.Series:
    r = pd.Series(returns).fillna(0.0); return (1 + r).cumprod() - 1.0
