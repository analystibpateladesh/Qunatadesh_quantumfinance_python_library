"""Statistical tests for time-series: ADF, Hurst, Ljung-Box, ACF."""
from __future__ import annotations
import numpy as np
from scipy.stats import chi2


def autocorrelation(x, lag: int = 1) -> float:
    x = np.asarray(x, dtype=float); x = x - x.mean()
    n = len(x)
    if lag >= n: raise ValueError("lag must be < len(x)")
    num = np.sum(x[:-lag] * x[lag:]); den = np.sum(x ** 2)
    return float(num / den)


def hurst_exponent(series, min_lag: int = 2, max_lag: int = 100) -> float:
    """R/S-style Hurst via variance scaling. H~0.5 random walk; >0.5 trending; <0.5 mean-reverting."""
    x = np.asarray(series, dtype=float)
    lags = np.arange(min_lag, min(max_lag, len(x) // 2))
    tau = [np.sqrt(np.std(np.subtract(x[lag:], x[:-lag]))) for lag in lags]
    poly = np.polyfit(np.log(lags), np.log(tau), 1)
    return float(poly[0] * 2.0)


def adf_test(series, max_lag: int = 5) -> dict:
    """
    Simplified Augmented Dickey-Fuller test (no constant/trend) — returns the
    t-stat on the lagged-level coefficient. For full statsmodels-style p-values,
    install statsmodels separately. This is a lightweight diagnostic.
    """
    y = np.asarray(series, dtype=float)
    dy = np.diff(y)
    n = len(dy)
    p = max_lag
    if n <= p + 5:
        raise ValueError("series too short for ADF with this lag")
    Y = dy[p:]
    X_cols = [y[p:-1]]  # lagged level
    for k in range(1, p + 1):
        X_cols.append(dy[p - k : -k])
    X = np.column_stack(X_cols)
    # OLS via lstsq
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    resid = Y - X @ beta
    sigma2 = (resid @ resid) / (len(Y) - X.shape[1])
    cov = sigma2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    tstat = beta[0] / se[0]
    return dict(tstat=float(tstat),
                interpretation="more negative = more stationary; ~< -2.86 ≈ 5% reject unit root")


def ljung_box(series, lags: int = 10) -> dict:
    """Ljung-Box Q test for autocorrelation."""
    x = np.asarray(series, dtype=float); x = x - x.mean()
    n = len(x)
    acf = [np.sum(x[:n - k] * x[k:]) / np.sum(x ** 2) for k in range(1, lags + 1)]
    Q = n * (n + 2) * sum((rho ** 2) / (n - k) for k, rho in enumerate(acf, start=1))
    p = 1 - chi2.cdf(Q, df=lags)
    return dict(Q=float(Q), p_value=float(p), lags=lags)
