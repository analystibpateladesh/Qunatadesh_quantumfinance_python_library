"""Conditional VaR / Expected Shortfall."""
from __future__ import annotations
import numpy as np
from scipy.stats import norm
from ..utils.results import RiskResult


def historical_cvar(returns, confidence: float = 0.95, horizon: int = 1) -> RiskResult:
    r = np.asarray(returns, dtype=float)
    cutoff = np.percentile(r, (1 - confidence) * 100)
    tail = r[r <= cutoff]
    cvar = -tail.mean() * np.sqrt(horizon) if len(tail) else 0.0
    return RiskResult(metric="CVaR", value=float(cvar), confidence=confidence,
                      method="historical", horizon=horizon)


def parametric_cvar(returns, confidence: float = 0.95, horizon: int = 1) -> RiskResult:
    r = np.asarray(returns, dtype=float)
    mu = r.mean(); sigma = r.std(ddof=1)
    alpha = 1 - confidence
    cvar = -(mu - sigma * norm.pdf(norm.ppf(alpha)) / alpha) * np.sqrt(horizon)
    return RiskResult(metric="CVaR", value=float(cvar), confidence=confidence,
                      method="parametric", horizon=horizon)
