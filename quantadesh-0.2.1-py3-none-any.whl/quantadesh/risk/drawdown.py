"""Drawdown analytics."""
from __future__ import annotations
import numpy as np
import pandas as pd


def drawdown_series(returns) -> pd.Series:
    r = pd.Series(returns).fillna(0.0)
    wealth = (1 + r).cumprod()
    peak = wealth.cummax()
    return wealth / peak - 1.0


def max_drawdown(returns) -> float:
    return float(drawdown_series(returns).min())
