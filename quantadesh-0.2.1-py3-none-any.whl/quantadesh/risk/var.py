"""Value-at-Risk: historical, parametric (variance-covariance), Monte Carlo."""
from __future__ import annotations
import numpy as np
from scipy.stats import norm
from typing import Optional
from ..utils.results import RiskResult


def historical_var(returns, confidence: float = 0.95, horizon: int = 1) -> RiskResult:
    r = np.asarray(returns, dtype=float)
    var = -np.percentile(r, (1 - confidence) * 100) * np.sqrt(horizon)
    return RiskResult(metric="VaR", value=float(var), confidence=confidence,
                      method="historical", horizon=horizon)


def parametric_var(returns, confidence: float = 0.95, horizon: int = 1) -> RiskResult:
    r = np.asarray(returns, dtype=float)
    mu = r.mean(); sigma = r.std(ddof=1)
    z = norm.ppf(1 - confidence)
    var = -(mu + z * sigma) * np.sqrt(horizon)
    return RiskResult(metric="VaR", value=float(var), confidence=confidence,
                      method="parametric", horizon=horizon,
                      extra=dict(mu=float(mu), sigma=float(sigma)))


def monte_carlo_var(mu: float, sigma: float, confidence: float = 0.95,
                    horizon: int = 1, paths: int = 100_000,
                    *, seed: Optional[int] = None) -> RiskResult:
    rng = np.random.default_rng(seed)
    sims = rng.normal(mu * horizon, sigma * np.sqrt(horizon), size=paths)
    var = -np.percentile(sims, (1 - confidence) * 100)
    return RiskResult(metric="VaR", value=float(var), confidence=confidence,
                      method="monte_carlo", horizon=horizon, extra=dict(paths=paths))
