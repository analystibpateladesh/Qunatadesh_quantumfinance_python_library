"""
Heston (1993) stochastic volatility model — semi-analytical via characteristic function.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import quad
from ..utils.validation import validate_option_type
from ..utils.results import PricingResult


def _heston_char(phi, S, K, T, r, v0, kappa, theta, sigma, rho, j):
    """Heston characteristic function (Albrecher et al. 'good' formulation)."""
    a = kappa * theta
    u = 0.5 if j == 1 else -0.5
    b = (kappa - rho * sigma) if j == 1 else kappa
    d = np.sqrt((rho * sigma * 1j * phi - b) ** 2 - sigma ** 2 * (2 * u * 1j * phi - phi ** 2))
    g = (b - rho * sigma * 1j * phi - d) / (b - rho * sigma * 1j * phi + d)
    C = r * 1j * phi * T + (a / sigma ** 2) * (
        (b - rho * sigma * 1j * phi - d) * T - 2 * np.log((1 - g * np.exp(-d * T)) / (1 - g))
    )
    D = ((b - rho * sigma * 1j * phi - d) / sigma ** 2) * (
        (1 - np.exp(-d * T)) / (1 - g * np.exp(-d * T))
    )
    return np.exp(C + D * v0 + 1j * phi * np.log(S))


def _heston_P(S, K, T, r, v0, kappa, theta, sigma, rho, j):
    def integrand(phi):
        cf = _heston_char(phi, S, K, T, r, v0, kappa, theta, sigma, rho, j)
        return np.real(np.exp(-1j * phi * np.log(K)) * cf / (1j * phi))
    val, _ = quad(integrand, 1e-8, 100.0, limit=200)
    return 0.5 + val / np.pi


def heston_price(
    S, K, T, r,
    v0: float, kappa: float, theta: float, sigma: float, rho: float,
    option_type: str = "call",
    *, return_result: bool = False,
):
    """
    Heston stochastic-vol European option price.

    Parameters
    ----------
    v0    : initial variance
    kappa : mean-reversion speed
    theta : long-run variance
    sigma : vol-of-vol
    rho   : correlation between asset and variance Brownian motions
    """
    ot = validate_option_type(option_type)
    P1 = _heston_P(S, K, T, r, v0, kappa, theta, sigma, rho, 1)
    P2 = _heston_P(S, K, T, r, v0, kappa, theta, sigma, rho, 2)
    call = S * P1 - K * np.exp(-r * T) * P2
    price = float(call) if ot == "call" else float(call - S + K * np.exp(-r * T))
    if return_result:
        return PricingResult(
            price=price, model="Heston", option_type=ot,
            inputs=dict(S=S, K=K, T=T, r=r, v0=v0, kappa=kappa, theta=theta, sigma=sigma, rho=rho),
        )
    return price
