"""Cox-Ross-Rubinstein binomial tree — supports European AND American exercise."""
from __future__ import annotations
import math
import numpy as np
from ..utils.validation import validate_option_type, validate_positive
from ..utils.results import PricingResult


def binomial_price(
    S, K, T, r, sigma, q=0.0,
    steps: int = 500,
    american: bool = False,
    option_type: str = "call",
    *,
    return_result: bool = False,
):
    """
    CRR binomial tree pricing for European or American options.

    Parameters
    ----------
    steps : number of time steps (more = more accurate, slower)
    american : if True, allow early exercise at every node
    """
    ot = validate_option_type(option_type)
    S = validate_positive("S", S)
    K = validate_positive("K", K)
    if T <= 0:
        return max(S - K, 0.0) if ot == "call" else max(K - S, 0.0)
    N = int(steps)
    dt = T / N
    u = math.exp(sigma * math.sqrt(dt))
    d = 1.0 / u
    p = (math.exp((r - q) * dt) - d) / (u - d)
    if not (0 < p < 1):
        raise ValueError(f"Risk-neutral probability {p:.4f} out of (0,1); reduce dt or check inputs")
    disc = math.exp(-r * dt)

    # terminal prices
    j = np.arange(N + 1)
    ST = S * (u ** (N - j)) * (d ** j)
    if ot == "call":
        V = np.maximum(ST - K, 0.0)
    else:
        V = np.maximum(K - ST, 0.0)

    for i in range(N - 1, -1, -1):
        V = disc * (p * V[:-1] + (1 - p) * V[1:])
        if american:
            j = np.arange(i + 1)
            St = S * (u ** (i - j)) * (d ** j)
            intrinsic = np.maximum(St - K, 0.0) if ot == "call" else np.maximum(K - St, 0.0)
            V = np.maximum(V, intrinsic)

    price = float(V[0])
    if return_result:
        return PricingResult(
            price=price,
            model=f"Binomial-CRR-{'American' if american else 'European'}",
            option_type=ot,
            inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma, q=q, steps=N, american=american),
        )
    return price
