"""
Monte Carlo pricing for European options under GBM.
Returns structured MCResult — never a bare tuple.
"""
from __future__ import annotations
import math
import numpy as np
from typing import Optional, Callable
from ..utils.validation import validate_option_type, validate_positive
from ..utils.results import MCResult


def mc_paths(
    S: float, T: float, r: float, sigma: float, q: float = 0.0,
    paths: int = 100_000, steps: int = 1, *,
    seed: Optional[int] = None, antithetic: bool = True,
) -> np.ndarray:
    """Simulate GBM paths. Returns array shape (paths, steps+1) starting at S."""
    rng = np.random.default_rng(seed)
    dt = T / steps
    n_half = paths // 2 if antithetic else paths
    Z = rng.standard_normal(size=(n_half, steps))
    if antithetic:
        Z = np.vstack([Z, -Z])
        if Z.shape[0] < paths:
            Z = np.vstack([Z, rng.standard_normal(size=(1, steps))])
    drift = (r - q - 0.5 * sigma * sigma) * dt
    diff = sigma * math.sqrt(dt) * Z
    log_paths = np.cumsum(drift + diff, axis=1)
    S_paths = S * np.exp(log_paths)
    return np.hstack([np.full((Z.shape[0], 1), S), S_paths])


def mc_price(
    S, K, T, r, sigma, q=0.0,
    paths: int = 100_000,
    option_type: str = "call",
    *,
    seed: Optional[int] = None,
    antithetic: bool = True,
    return_paths: bool = False,
) -> MCResult:
    """
    European option Monte Carlo price under GBM. ALWAYS returns MCResult.
    """
    ot = validate_option_type(option_type)
    S = validate_positive("S", S)
    K = validate_positive("K", K)
    rng = np.random.default_rng(seed)

    n_half = paths // 2 if antithetic else paths
    Z = rng.standard_normal(n_half)
    if antithetic:
        Z = np.concatenate([Z, -Z])
    n = len(Z)

    ST = S * np.exp((r - q - 0.5 * sigma * sigma) * T + sigma * math.sqrt(T) * Z)
    payoff = np.maximum(ST - K, 0.0) if ot == "call" else np.maximum(K - ST, 0.0)
    disc_payoff = math.exp(-r * T) * payoff

    price = float(disc_payoff.mean())
    se = float(disc_payoff.std(ddof=1) / math.sqrt(n))
    ci95 = (price - 1.96 * se, price + 1.96 * se)

    return MCResult(
        price=price, se=se, paths=n, ci95=ci95,
        model="MonteCarlo-GBM", option_type=ot,
        payoff_samples=disc_payoff if return_paths else None,
        inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma, q=q, antithetic=antithetic, seed=seed),
    )
