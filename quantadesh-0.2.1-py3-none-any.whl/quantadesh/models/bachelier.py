"""Bachelier (normal) model — used for negative-rate environments and some commodities."""
from __future__ import annotations
import math
import numpy as np
from scipy.stats import norm
from ..utils.validation import validate_option_type
from ..utils.results import PricingResult


def bachelier_price(S, K, T, r, sigma, option_type="call", *, return_result=False):
    """
    Bachelier (arithmetic Brownian motion) European option price.
    `sigma` here is the absolute (normal) vol, not lognormal.
    """
    ot = validate_option_type(option_type)
    if T == 0:
        price = max(S - K, 0.0) if ot == "call" else max(K - S, 0.0)
    else:
        d = (S - K) / (sigma * math.sqrt(T))
        disc = math.exp(-r * T)
        if ot == "call":
            price = disc * ((S - K) * norm.cdf(d) + sigma * math.sqrt(T) * norm.pdf(d))
        else:
            price = disc * ((K - S) * norm.cdf(-d) + sigma * math.sqrt(T) * norm.pdf(d))
    if return_result:
        return PricingResult(price=price, model="Bachelier", option_type=ot,
                             inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma))
    return price
