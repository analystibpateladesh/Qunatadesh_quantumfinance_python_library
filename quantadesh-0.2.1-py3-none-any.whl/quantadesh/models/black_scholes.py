"""
Black-Scholes-Merton pricing & implied volatility.

Convention:
    All pricing functions follow the signature:
        f(S, K, T, r, sigma, ..., option_type="call")
    with `option_type` LAST and defaulting to "call".
"""
from __future__ import annotations
import math
from typing import Union
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq

from ..utils.validation import validate_option_type, validate_positive, validate_nonneg
from ..utils.results import PricingResult


def d1(S: float, K: float, T: float, r: float, sigma: float, q: float = 0.0) -> float:
    return (math.log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * math.sqrt(T))


def d2(S: float, K: float, T: float, r: float, sigma: float, q: float = 0.0) -> float:
    return d1(S, K, T, r, sigma, q) - sigma * math.sqrt(T)


def bs_price(
    S: float,
    K: float,
    T: float,
    r: float,
    sigma: float,
    q: float = 0.0,
    option_type: str = "call",
    *,
    return_result: bool = False,
) -> Union[float, PricingResult]:
    """
    Black-Scholes-Merton price for a European option (with continuous dividend yield q).

    Parameters
    ----------
    S : spot price
    K : strike
    T : time to maturity (years)
    r : risk-free rate (cont. comp.)
    sigma : volatility
    q : continuous dividend yield (default 0)
    option_type : 'call' or 'put'
    return_result : if True, returns a PricingResult object (default False -> float)
    """
    S = validate_positive("S", S)
    K = validate_positive("K", K)
    T = validate_nonneg("T", T)
    sigma = validate_nonneg("sigma", sigma)
    ot = validate_option_type(option_type)

    if T == 0 or sigma == 0:
        intrinsic = max(S - K, 0.0) if ot == "call" else max(K - S, 0.0)
        price = intrinsic
    else:
        _d1 = d1(S, K, T, r, sigma, q)
        _d2 = _d1 - sigma * math.sqrt(T)
        if ot == "call":
            price = S * math.exp(-q * T) * norm.cdf(_d1) - K * math.exp(-r * T) * norm.cdf(_d2)
        else:
            price = K * math.exp(-r * T) * norm.cdf(-_d2) - S * math.exp(-q * T) * norm.cdf(-_d1)

    if return_result:
        return PricingResult(
            price=price, model="Black-Scholes", option_type=ot,
            inputs=dict(S=S, K=K, T=T, r=r, sigma=sigma, q=q),
        )
    return price


def bs_implied_vol(
    price: float,
    S: float,
    K: float,
    T: float,
    r: float,
    q: float = 0.0,
    option_type: str = "call",
    *,
    tol: float = 1e-8,
    max_iter: int = 200,
) -> float:
    """Implied volatility via Brent's method on the Black-Scholes formula."""
    ot = validate_option_type(option_type)
    intrinsic = (
        max(S * math.exp(-q * T) - K * math.exp(-r * T), 0.0) if ot == "call"
        else max(K * math.exp(-r * T) - S * math.exp(-q * T), 0.0)
    )
    if price < intrinsic - 1e-10:
        raise ValueError(f"price {price} below intrinsic value {intrinsic}; no IV exists")

    def obj(sig: float) -> float:
        return bs_price(S, K, T, r, sig, q, ot) - price

    try:
        return brentq(obj, 1e-6, 5.0, xtol=tol, maxiter=max_iter)
    except ValueError:
        # widen bracket
        return brentq(obj, 1e-9, 20.0, xtol=tol, maxiter=max_iter)
