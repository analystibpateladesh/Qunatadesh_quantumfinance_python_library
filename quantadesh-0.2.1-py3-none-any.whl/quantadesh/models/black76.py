"""Black-76 model — for options on futures / forwards."""
from __future__ import annotations
import math
from scipy.stats import norm
from ..utils.validation import validate_option_type
from ..utils.results import PricingResult


def black76_price(F, K, T, r, sigma, option_type="call", *, return_result=False):
    """
    Black-76 European option on a forward/future F.

    Parameters
    ----------
    F : forward / futures price
    K : strike
    T : time to maturity
    r : risk-free rate (for discounting)
    sigma : implied vol
    """
    ot = validate_option_type(option_type)
    if T == 0:
        price = math.exp(-r * T) * (max(F - K, 0.0) if ot == "call" else max(K - F, 0.0))
    else:
        d1 = (math.log(F / K) + 0.5 * sigma * sigma * T) / (sigma * math.sqrt(T))
        d2 = d1 - sigma * math.sqrt(T)
        disc = math.exp(-r * T)
        if ot == "call":
            price = disc * (F * norm.cdf(d1) - K * norm.cdf(d2))
        else:
            price = disc * (K * norm.cdf(-d2) - F * norm.cdf(-d1))
    if return_result:
        return PricingResult(price=price, model="Black-76", option_type=ot,
                             inputs=dict(F=F, K=K, T=T, r=r, sigma=sigma))
    return price
